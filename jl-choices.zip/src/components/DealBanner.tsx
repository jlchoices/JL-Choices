import React from 'react';
import { ArrowRight, Flame, Clock, Sparkles, Zap, Percent } from 'lucide-react';
import { CategorySlug } from '../types';

interface DealBannerProps {
  onExploreCategory: (category: CategorySlug) => void;
}

export const DealBanner: React.FC<DealBannerProps> = ({ onExploreCategory }) => {
  return (
    <section className="py-12 bg-[#FFFDF9]" id="deals-banner-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-8">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-100 text-pink-700 text-xs font-bold mb-2">
            <Flame className="w-3.5 h-3.5 text-pink-600" />
            <span>High Discount Zone</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-zinc-900 tracking-tight">
            🔥 Deals You Don't Want To Miss
          </h2>
          <p className="text-sm text-zinc-600 mt-2">
            Hand-curated flash bargains with verified price drops across major online platforms.
          </p>
        </div>

        {/* Big Colorful Deal Banners Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          
          {/* Card 1: Orange-Pink Gradient (Electronics & Gadgets) */}
          <div className="relative overflow-hidden rounded-3xl p-6 sm:p-7 text-white bg-gradient-to-br from-orange-500 via-pink-500 to-rose-600 shadow-xl flex flex-col justify-between group min-h-[260px]">
            <div className="absolute top-0 right-0 -mr-8 -mt-8 w-44 h-44 bg-white/10 rounded-full blur-xl pointer-events-none group-hover:scale-125 transition-transform duration-700" />
            
            <div className="relative z-10">
              <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/20 backdrop-blur-xs text-xs font-bold text-white mb-3">
                <Clock className="w-3.5 h-3.5" />
                <span>Limited Time Deals</span>
              </div>
              <h3 className="text-3xl sm:text-4xl font-black tracking-tight leading-none mb-2">
                UP TO 70% OFF
              </h3>
              <p className="text-white/90 text-sm font-medium">
                Audio gear, wireless power banks & smart desk accessories.
              </p>
            </div>

            <div className="relative z-10 pt-6">
              <button
                onClick={() => onExploreCategory('gadgets')}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs bg-white text-zinc-900 hover:bg-zinc-100 shadow-md group-hover:translate-x-1 transition-all"
              >
                <span>Shop Now</span>
                <ArrowRight className="w-3.5 h-3.5 text-pink-600" />
              </button>
            </div>
          </div>

          {/* Card 2: Purple-Pink Gradient (Fashion & Lifestyle) */}
          <div className="relative overflow-hidden rounded-3xl p-6 sm:p-7 text-white bg-gradient-to-br from-purple-600 via-pink-600 to-amber-500 shadow-xl flex flex-col justify-between group min-h-[260px]">
            <div className="absolute bottom-0 right-0 -mr-6 -mb-6 w-40 h-40 bg-yellow-400/20 rounded-full blur-xl pointer-events-none group-hover:scale-125 transition-transform duration-700" />

            <div className="relative z-10">
              <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/20 backdrop-blur-xs text-xs font-bold text-white mb-3">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Fashion Steals</span>
              </div>
              <h3 className="text-3xl sm:text-4xl font-black tracking-tight leading-none mb-2">
                UP TO 65% OFF
              </h3>
              <p className="text-white/90 text-sm font-medium">
                Casual streetwear, sneakers, vegan leather bags & daily chic.
              </p>
            </div>

            <div className="relative z-10 pt-6">
              <button
                onClick={() => onExploreCategory('fashion')}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs bg-white text-zinc-900 hover:bg-zinc-100 shadow-md group-hover:translate-x-1 transition-all"
              >
                <span>Shop Now</span>
                <ArrowRight className="w-3.5 h-3.5 text-purple-600" />
              </button>
            </div>
          </div>

          {/* Card 3: Yellow-Orange-Purple Gradient (Home & Kitchen Essentials) */}
          <div className="relative overflow-hidden rounded-3xl p-6 sm:p-7 text-zinc-900 bg-gradient-to-br from-amber-400 via-orange-400 to-pink-500 shadow-xl flex flex-col justify-between group min-h-[260px] md:col-span-2 lg:col-span-1">
            <div className="absolute top-0 right-0 -mr-8 -mt-8 w-44 h-44 bg-white/25 rounded-full blur-xl pointer-events-none group-hover:scale-125 transition-transform duration-700" />

            <div className="relative z-10">
              <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-black/10 backdrop-blur-xs text-xs font-bold text-zinc-900 mb-3">
                <Zap className="w-3.5 h-3.5" />
                <span>Budget Organizers</span>
              </div>
              <h3 className="text-3xl sm:text-4xl font-black tracking-tight leading-none text-zinc-950 mb-2">
                UNDER ₹499
              </h3>
              <p className="text-zinc-900/90 text-sm font-medium">
                Multi-tier spice racks, ceramic vases & aesthetic home storage.
              </p>
            </div>

            <div className="relative z-10 pt-6">
              <button
                onClick={() => onExploreCategory('home')}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs bg-zinc-950 text-white hover:bg-zinc-900 shadow-md group-hover:translate-x-1 transition-all"
              >
                <span>Shop Now</span>
                <ArrowRight className="w-3.5 h-3.5 text-yellow-300" />
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
