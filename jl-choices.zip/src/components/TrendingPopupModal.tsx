import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Product } from '../types';
import { Flame, X, ExternalLink, Star, ArrowRight, Sparkles, Check, ShoppingBag, Tag } from 'lucide-react';

interface TrendingPopupModalProps {
  products: Product[];
  onOpenDetails: (product: Product) => void;
  onExploreAllTrending: () => void;
}

export const TrendingPopupModal: React.FC<TrendingPopupModalProps> = ({
  products,
  onOpenDetails,
  onExploreAllTrending,
}) => {
  // Start with isOpen = false, then automatically open on website load
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [dontShowAgain, setDontShowAgain] = useState<boolean>(false);

  // Top trending items from the catalog
  const trendingProducts = products.filter((p) => p.isTrending).slice(0, 4);

  // Automatically trigger popup when someone is opening the website
  useEffect(() => {
    // Only suppress if the user explicitly ticked "Don't show this popup again"
    const isPermanentlyMuted = localStorage.getItem('jl_choices_trending_popup_muted_v2');

    if (!isPermanentlyMuted) {
      // Promptly open on page opening (400ms delay for smooth entrance transition)
      const timer = setTimeout(() => {
        setIsOpen(true);
      }, 400);
      return () => clearTimeout(timer);
    }
  }, []);

  // Lock body scroll when modal is active
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        handleClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, dontShowAgain]);

  const handleClose = () => {
    setIsOpen(false);
    if (dontShowAgain) {
      localStorage.setItem('jl_choices_trending_popup_muted_v2', 'true');
    }
  };

  const handleProductClick = (product: Product) => {
    handleClose();
    onOpenDetails(product);
  };

  const handleExploreAll = () => {
    handleClose();
    onExploreAllTrending();
  };

  const getMarketplaceBadge = (marketplace: Product['marketplace']) => {
    switch (marketplace) {
      case 'Amazon':
        return {
          bg: 'bg-amber-500/10 text-amber-800 border-amber-300/80',
          dot: 'bg-amber-500',
        };
      case 'Flipkart':
        return {
          bg: 'bg-blue-500/10 text-blue-800 border-blue-300/80',
          dot: 'bg-blue-500',
        };
      case 'Myntra':
        return {
          bg: 'bg-pink-500/10 text-pink-800 border-pink-300/80',
          dot: 'bg-pink-500',
        };
      case 'Meesho':
        return {
          bg: 'bg-purple-500/10 text-purple-800 border-purple-300/80',
          dot: 'bg-purple-500',
        };
      default:
        return {
          bg: 'bg-zinc-100 text-zinc-800 border-zinc-200',
          dot: 'bg-zinc-400',
        };
    }
  };

  return (
    <>
      {/* Pop-up Modal Backdrop & Content */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto">
            {/* Backdrop with Blur */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              onClick={handleClose}
              className="fixed inset-0 bg-black/65 backdrop-blur-md"
              aria-hidden="true"
            />

            {/* Modal Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 24 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 16 }}
              transition={{ type: 'spring', damping: 26, stiffness: 340 }}
              className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-orange-200/90 overflow-hidden z-10 my-auto flex flex-col max-h-[92vh]"
              role="dialog"
              aria-modal="true"
              aria-labelledby="trending-popup-title"
            >
              {/* Top Accent Gradient Bar */}
              <div className="h-1.5 w-full bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600" />

              {/* Accessible Close Button */}
              <button
                onClick={handleClose}
                id="trending-popup-close-btn"
                className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-zinc-100/90 hover:bg-zinc-200 text-zinc-600 hover:text-zinc-950 transition-colors shadow-2xs focus:outline-none focus:ring-2 focus:ring-orange-400 cursor-pointer"
                aria-label="Close trending popup"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Modal Header */}
              <div className="pt-5 px-5 sm:pt-6 sm:px-8 pb-3.5 bg-gradient-to-b from-orange-50/70 via-pink-50/30 to-white border-b border-zinc-100 flex-shrink-0">
                <div className="flex flex-wrap items-center justify-between gap-3 pr-10">
                  <div className="flex items-center gap-3">
                    {/* Glowing Trending Flame Icon */}
                    <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-tr from-orange-500 via-pink-500 to-rose-500 flex items-center justify-center text-white shadow-md shadow-orange-500/25 flex-shrink-0">
                      <Flame className="w-6 h-6 fill-white animate-pulse" />
                    </div>
                    <div>
                      {/* Pill Badge */}
                      <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-gradient-to-r from-orange-500 to-pink-500 text-white text-[11px] font-extrabold shadow-2xs">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>VIRAL & TRENDING TODAY</span>
                      </div>
                      <h2
                        id="trending-popup-title"
                        className="text-xl sm:text-2xl font-black text-zinc-900 tracking-tight mt-1"
                      >
                        Trending Products on JL Choices
                      </h2>
                    </div>
                  </div>
                </div>
                <p className="text-xs sm:text-sm text-zinc-600 mt-2 max-w-2xl">
                  Discover today&apos;s most viral deals and fast-selling picks across Amazon, Flipkart, Myntra, and Meesho with up to <span className="font-extrabold text-orange-600">65% OFF</span>.
                </p>
              </div>

              {/* Modal Body: Trending Products Grid */}
              <div className="p-4 sm:p-6 overflow-y-auto flex-1">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
                  {trendingProducts.map((product) => {
                    const badge = getMarketplaceBadge(product.marketplace);
                    return (
                      <div
                        key={product.id}
                        id={`trending-popup-item-${product.id}`}
                        onClick={() => handleProductClick(product)}
                        className="group flex flex-col bg-zinc-50/70 hover:bg-white rounded-2xl border border-zinc-200/90 hover:border-orange-400 hover:shadow-xl transition-all duration-200 overflow-hidden cursor-pointer p-3 text-left relative"
                      >
                        {/* Image Container with Badges */}
                        <div className="relative aspect-4/3 rounded-xl overflow-hidden bg-white border border-zinc-150 mb-2.5">
                          <img
                            src={product.image}
                            alt={product.name}
                            loading="lazy"
                            className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-300"
                          />
                          {/* Discount tag */}
                          <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-gradient-to-r from-orange-500 to-pink-500 text-white text-[10px] font-black shadow-xs">
                            {product.discount}% OFF
                          </div>
                          {/* Marketplace badge */}
                          <div
                            className={`absolute top-2 right-2 px-2 py-0.5 rounded-md text-[10px] font-bold border backdrop-blur-xs shadow-2xs ${badge.bg}`}
                          >
                            {product.marketplace}
                          </div>
                        </div>

                        {/* Title & Ratings */}
                        <div className="flex-1 flex flex-col justify-between">
                          <div>
                            <div className="flex items-center gap-1 text-amber-500 text-xs mb-1">
                              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                              <span className="font-bold text-zinc-800 text-[11px]">{product.rating}</span>
                              <span className="text-zinc-400 text-[10px]">({product.reviewCount.toLocaleString('en-IN')})</span>
                            </div>

                            <h3 className="text-xs sm:text-[13px] font-bold text-zinc-900 line-clamp-2 leading-snug group-hover:text-orange-600 transition-colors">
                              {product.name}
                            </h3>
                          </div>

                          {/* Pricing & CTA */}
                          <div className="mt-3 pt-2.5 border-t border-zinc-200/60 flex items-baseline justify-between">
                            <div>
                              <div className="flex items-baseline gap-1.5">
                                <span className="text-sm font-black text-zinc-950">
                                  ₹{product.price.toLocaleString('en-IN')}
                                </span>
                                {product.originalPrice && (
                                  <span className="text-[11px] text-zinc-400 line-through">
                                    ₹{product.originalPrice.toLocaleString('en-IN')}
                                  </span>
                                )}
                              </div>
                            </div>
                            <span className="text-[11px] font-bold text-orange-600 group-hover:translate-x-0.5 transition-transform inline-flex items-center gap-0.5">
                              View <ArrowRight className="w-3 h-3" />
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Modal Footer: Action Bar */}
              <div className="px-5 py-3.5 sm:px-8 sm:py-4 bg-zinc-50 border-t border-zinc-200/80 flex flex-col sm:flex-row items-center justify-between gap-3 flex-shrink-0">
                {/* Optional Checkbox */}
                <label className="flex items-center gap-2 cursor-pointer text-xs text-zinc-600 hover:text-zinc-900 select-none">
                  <input
                    type="checkbox"
                    checked={dontShowAgain}
                    onChange={(e) => setDontShowAgain(e.target.checked)}
                    className="w-4 h-4 rounded text-orange-600 focus:ring-orange-500 border-zinc-300"
                  />
                  <span>Don&apos;t show this popup again</span>
                </label>

                {/* Primary CTA Buttons */}
                <div className="flex items-center gap-2.5 w-full sm:w-auto">
                  <button
                    onClick={handleClose}
                    className="flex-1 sm:flex-none px-4 py-2 rounded-xl border border-zinc-300 text-xs font-bold text-zinc-700 hover:bg-zinc-100 transition-colors text-center cursor-pointer"
                  >
                    Continue Browsing
                  </button>
                  <button
                    onClick={handleExploreAll}
                    id="trending-popup-explore-all-btn"
                    className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 hover:from-orange-600 hover:to-pink-600 text-white text-xs font-bold shadow-md shadow-orange-500/20 hover:shadow-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Flame className="w-3.5 h-3.5 fill-white" />
                    <span>Explore All Trending ({products.filter(p => p.isTrending).length})</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Floating Re-open Pill when modal is closed */}
      {!isOpen && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsOpen(true)}
          id="reopen-trending-popup-btn"
          className="fixed bottom-5 left-5 z-40 flex items-center gap-2 px-3.5 py-2 rounded-full bg-white/95 backdrop-blur-md border border-orange-200 shadow-lg text-zinc-900 text-xs font-bold hover:border-orange-400 hover:shadow-xl transition-all group cursor-pointer"
          title="View Trending Products"
        >
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500"></span>
          </span>
          <Flame className="w-4 h-4 text-orange-500 fill-orange-500 group-hover:scale-110 transition-transform" />
          <span className="bg-gradient-to-r from-orange-600 to-pink-600 bg-clip-text text-transparent font-extrabold">
            Trending Deals
          </span>
          <span className="px-1.5 py-0.5 rounded-full bg-orange-100 text-orange-800 text-[10px] font-black">
            {products.filter((p) => p.isTrending).length}
          </span>
        </motion.button>
      )}
    </>
  );
};
