import React, { useState } from 'react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';
import {
  ExternalLink,
  Star,
  ShieldCheck,
  CheckCircle2,
  ArrowLeft,
  Share2,
  Tag,
  Clock,
  Truck,
  RotateCcw,
  Sparkles
} from 'lucide-react';

interface ProductDetailPageProps {
  product: Product;
  allProducts: Product[];
  onBack: () => void;
  onOpenDetails: (product: Product) => void;
  onNavigateCategory: (category: Product['category']) => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  product,
  allProducts,
  onBack,
  onOpenDetails,
  onNavigateCategory,
}) => {
  const images = [product.image, ...(product.additionalImages || [])];
  const [selectedImage, setSelectedImage] = useState(product.image);
  const [copiedLink, setCopiedLink] = useState(false);

  // Find related products (same category, excluding current)
  const relatedProducts = allProducts
    .filter((p) => p.id !== product.id && (p.category === product.category || p.marketplace === product.marketplace))
    .slice(0, 4);

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const getMarketplaceTheme = (mp: Product['marketplace']) => {
    switch (mp) {
      case 'Amazon':
        return {
          btnGradient: 'from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700',
          textColor: 'text-amber-700',
          bgPill: 'bg-amber-100 text-amber-900 border-amber-300',
          storeNote: 'Dispatched and delivered by Amazon India with 7-day replacement policy.',
        };
      case 'Flipkart':
        return {
          btnGradient: 'from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700',
          textColor: 'text-blue-700',
          bgPill: 'bg-blue-100 text-blue-900 border-blue-300',
          storeNote: 'Flipkart Assured quality delivery with SuperCoins cashback eligible.',
        };
      case 'Myntra':
        return {
          btnGradient: 'from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700',
          textColor: 'text-pink-700',
          bgPill: 'bg-pink-100 text-pink-900 border-pink-300',
          storeNote: 'Original brand guarantee with easy 14-day door-step return & exchanges.',
        };
      case 'Meesho':
        return {
          btnGradient: 'from-purple-600 to-fuchsia-700 hover:from-purple-700 hover:to-fuchsia-800',
          textColor: 'text-purple-700',
          bgPill: 'bg-purple-100 text-purple-900 border-purple-300',
          storeNote: 'Lowest price guarantee with Cash on Delivery (COD) available.',
        };
      default:
        return {
          btnGradient: 'from-zinc-900 to-zinc-800',
          textColor: 'text-zinc-800',
          bgPill: 'bg-zinc-100 text-zinc-800 border-zinc-300',
          storeNote: 'Secure checkout and direct shipping by merchant platform.',
        };
    }
  };

  const mpTheme = getMarketplaceTheme(product.marketplace);

  return (
    <div className="py-8 bg-[#FFFDF9] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Breadcrumbs & Back Button */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-zinc-200 text-xs sm:text-sm font-bold text-zinc-700 hover:bg-zinc-50 shadow-2xs transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Finds</span>
          </button>

          <nav className="flex items-center gap-1.5 text-xs text-zinc-500 overflow-x-auto py-1">
            <button onClick={onBack} className="hover:text-zinc-900 font-medium">Home</button>
            <span>/</span>
            <button
              onClick={() => onNavigateCategory(product.category)}
              className="hover:text-zinc-900 font-medium capitalize"
            >
              {product.category}
            </button>
            <span>/</span>
            <span className="text-zinc-900 font-bold truncate max-w-[200px]">
              {product.name}
            </span>
          </nav>
        </div>

        {/* Product Showcase Card */}
        <div className="bg-white rounded-3xl border border-zinc-200/80 shadow-lg p-5 sm:p-8 lg:p-10 mb-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
            
            {/* Left: Images Column (5 Cols) */}
            <div className="lg:col-span-5 flex flex-col gap-4">
              {/* Main Image Display */}
              <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-zinc-50 border border-zinc-200/80 shadow-xs group">
                <img
                  src={selectedImage}
                  alt={product.name}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                />

                {/* Badges on Image */}
                <div className="absolute top-3 left-3 flex flex-col gap-1.5">
                  <span className="px-3 py-1 rounded-lg text-xs font-black bg-gradient-to-r from-orange-500 to-pink-500 text-white shadow-md">
                    {product.discount}% OFF
                  </span>
                  {product.badge && (
                    <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-zinc-900/90 text-white backdrop-blur-xs">
                      {product.badge}
                    </span>
                  )}
                </div>

                {/* Marketplace Badge Overlay */}
                <div className="absolute bottom-3 right-3">
                  <span className={`px-3 py-1 rounded-md text-xs font-extrabold border backdrop-blur-md bg-white/95 shadow-xs ${mpTheme.bgPill}`}>
                    {product.marketplace}
                  </span>
                </div>
              </div>

              {/* Thumbnails if multiple images */}
              {images.length > 1 && (
                <div className="flex items-center gap-3 overflow-x-auto pb-1">
                  {images.map((img, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImage(img)}
                      className={`w-16 h-16 rounded-xl overflow-hidden border-2 flex-shrink-0 transition-all ${
                        selectedImage === img
                          ? 'border-pink-500 ring-2 ring-pink-500/20 scale-105'
                          : 'border-zinc-200 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt={`Thumbnail ${index + 1}`} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              {/* Buyer Confidence Guarantees */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-zinc-50 border border-zinc-200/60 flex items-center gap-2.5 text-xs text-zinc-700">
                  <Truck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                  <span className="font-medium">Direct Delivery by {product.marketplace}</span>
                </div>
                <div className="p-3 rounded-xl bg-zinc-50 border border-zinc-200/60 flex items-center gap-2.5 text-xs text-zinc-700">
                  <RotateCcw className="w-4 h-4 text-blue-600 flex-shrink-0" />
                  <span className="font-medium">Easy Returns & Exchanges</span>
                </div>
              </div>
            </div>

            {/* Right: Product Details & Affiliate CTA (7 Cols) */}
            <div className="lg:col-span-7 flex flex-col">
              
              {/* Marketplace Header Pill */}
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className={`text-xs font-extrabold px-3 py-1 rounded-full border ${mpTheme.bgPill}`}>
                  Available on {product.marketplace} India
                </span>

                <button
                  onClick={handleShare}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 transition-colors"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>{copiedLink ? 'Link Copied!' : 'Share Deal'}</span>
                </button>
              </div>

              {/* Title */}
              <h1 className="text-2xl sm:text-3xl font-black text-zinc-900 tracking-tight leading-tight mb-3">
                {product.name}
              </h1>

              {/* Rating and Reviews */}
              <div className="flex items-center gap-3 mb-5">
                <div className="flex items-center gap-1 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-lg text-xs font-bold text-amber-800">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                  <span>{product.rating} / 5.0</span>
                </div>
                <span className="text-xs text-zinc-500 font-medium">
                  Verified rating based on {product.reviewCount.toLocaleString()} customer reviews
                </span>
              </div>

              {/* Price Banner Box */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-orange-50/70 via-pink-50/50 to-white border border-pink-200/70 mb-6">
                <div className="flex flex-wrap items-baseline gap-3 mb-1">
                  <span className="text-3xl sm:text-4xl font-black text-zinc-900 tracking-tight">
                    ₹{product.price.toLocaleString('en-IN')}
                  </span>
                  {product.originalPrice > product.price && (
                    <span className="text-base sm:text-lg text-zinc-600 line-through font-semibold">
                      ₹{product.originalPrice.toLocaleString('en-IN')}
                    </span>
                  )}
                  <span className="px-2.5 py-0.5 rounded-md text-xs font-black bg-gradient-to-r from-orange-500 to-pink-500 text-white shadow-xs">
                    {product.discount}% SAVINGS
                  </span>
                </div>
                <p className="text-xs text-emerald-700 font-bold">
                  You save ₹{(product.originalPrice - product.price).toLocaleString('en-IN')} off regular pricing!
                </p>
              </div>

              {/* Description */}
              <div className="mb-6">
                <h2 className="text-sm font-bold text-zinc-900 uppercase tracking-wider mb-2">
                  Product Overview
                </h2>
                <p className="text-sm text-zinc-600 leading-relaxed">
                  {product.description}
                </p>
              </div>

              {/* Key Features */}
              {product.features && product.features.length > 0 && (
                <div className="mb-8">
                  <h2 className="text-sm font-bold text-zinc-900 uppercase tracking-wider mb-3">
                    Key Highlights & Features
                  </h2>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {product.features.map((feature, idx) => (
                      <li
                        key={idx}
                        className="flex items-start gap-2 text-xs sm:text-sm text-zinc-700 font-medium"
                      >
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Primary Call to Action Button */}
              <div className="mt-auto pt-6 border-t border-zinc-100">
                <a
                  id="product-detail-affiliate-cta"
                  href={product.affiliateUrl}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className={`w-full py-4 px-6 rounded-2xl font-black text-base text-white shadow-lg bg-gradient-to-r ${mpTheme.btnGradient} transition-all duration-200 flex items-center justify-center gap-2 active:scale-98`}
                >
                  <span>View Best Deal on {product.marketplace}</span>
                  <ExternalLink className="w-5 h-5" />
                </a>

                {/* Marketplace Tip / Note */}
                <div className="mt-3 flex items-center justify-between text-xs text-zinc-500">
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{mpTheme.storeNote}</span>
                  </span>
                  <span className="font-semibold text-zinc-400 hidden sm:inline">
                    Secure redirect
                  </span>
                </div>

                {/* Affiliate Disclosure Note */}
                <div className="mt-4 p-3 rounded-xl bg-zinc-50 border border-zinc-200 text-[11px] text-zinc-500 leading-normal">
                  <strong>Affiliate Transparency:</strong> Clicking the button above redirects you directly to {product.marketplace}. As an affiliate, JL Choices may earn a small referral commission if you complete a purchase, at zero additional cost to you.
                </div>
              </div>

            </div>

          </div>
        </div>

        {/* Related Finds Section */}
        {relatedProducts.length > 0 && (
          <div className="mt-12">
            <div className="flex items-center justify-between mb-6">
              <div>
                <div className="inline-flex items-center gap-1.5 text-xs font-bold text-pink-600 uppercase tracking-wider mb-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>You May Also Like</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-zinc-900 tracking-tight">
                  Similar Deals & Picks
                </h3>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
              {relatedProducts.map((relProduct) => (
                <ProductCard
                  key={`related-${relProduct.id}`}
                  product={relProduct}
                  onOpenDetails={onOpenDetails}
                />
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
