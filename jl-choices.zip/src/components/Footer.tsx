import React from 'react';
import { BRAND_CONFIG } from '../config/brand';
import { Instagram, Youtube, Facebook, Linkedin, ShieldAlert, Heart } from 'lucide-react';
import { CategorySlug } from '../types';
import logoImg from '../assets/logo.png';

interface FooterProps {
  onNavigate: (route: string, category?: CategorySlug | 'all') => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-zinc-950 text-zinc-300 border-t border-zinc-800 pt-14 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-zinc-800/80">
          
          {/* Brand Column (Span 2) */}
          <div className="lg:col-span-2 space-y-4 flex flex-col items-center text-center">
            {/* Official Brand Logo */}
            <div
              onClick={() => onNavigate('/')}
              className="cursor-pointer inline-block group mx-auto"
              id="footer-brand-logo"
            >
              <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden border-2 border-orange-400/80 shadow-xl shadow-orange-500/15 bg-[#FFFDF9] transition-transform duration-200 group-hover:scale-105 mx-auto">
                <img
                  src={logoImg}
                  alt="JL Choices Official Brand Logo"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <p className="text-sm font-semibold text-zinc-300 text-center">
              {BRAND_CONFIG.tagline}
            </p>

            <p className="text-xs sm:text-sm text-zinc-400 max-w-sm leading-relaxed text-center mx-auto">
              JL Choices is an independent affiliate product discovery platform. We hand-curate useful, trending, and budget-friendly products from Amazon, Flipkart, Myntra, and Meesho.
            </p>

            {/* Social Icons */}
            <div className="flex items-center justify-center gap-3 pt-2">
              <a
                id="footer-social-instagram"
                href={BRAND_CONFIG.socials.instagram}
                target="_blank"
                rel="noopener noreferrer"
                title="Follow JL Choices on Instagram"
                className="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-pink-400 hover:border-pink-500/40 hover:bg-zinc-800 transition-colors"
                aria-label="Follow JL Choices on Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                id="footer-social-youtube"
                href={BRAND_CONFIG.socials.youtube}
                target="_blank"
                rel="noopener noreferrer"
                title="Subscribe to JL Choices on YouTube"
                className="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-red-400 hover:border-red-500/40 hover:bg-zinc-800 transition-colors"
                aria-label="Subscribe to JL Choices on YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
              <a
                id="footer-social-facebook"
                href={BRAND_CONFIG.socials.facebook}
                target="_blank"
                rel="noopener noreferrer"
                title="Follow JL Choices on Facebook"
                className="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-blue-400 hover:border-blue-500/40 hover:bg-zinc-800 transition-colors"
                aria-label="Follow JL Choices on Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                id="footer-social-linkedin"
                href={BRAND_CONFIG.socials.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                title="Connect with JL Choices on LinkedIn"
                className="w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-blue-300 hover:border-blue-400/40 hover:bg-zinc-800 transition-colors"
                aria-label="Connect with JL Choices on LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">
              Quick Links
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <button
                  onClick={() => onNavigate('/')}
                  className="hover:text-white transition-colors"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/deals', 'deals')}
                  className="hover:text-white transition-colors flex items-center gap-1.5"
                >
                  <span>Today's Deals</span>
                  <span className="text-[10px] font-bold text-orange-400 bg-orange-950/60 px-1.5 py-0.5 rounded border border-orange-800/40">HOT</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/trending', 'trending')}
                  className="hover:text-white transition-colors"
                >
                  Trending Products
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/', 'all')}
                  className="hover:text-white transition-colors"
                >
                  All Categories
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/about')}
                  className="hover:text-white transition-colors"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/contact')}
                  className="hover:text-white transition-colors"
                >
                  Contact Us
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Top Categories */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">
              Categories
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <button
                  onClick={() => onNavigate('/category/gadgets', 'gadgets')}
                  className="hover:text-white transition-colors"
                >
                  Gadgets & Electronics
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/category/fashion', 'fashion')}
                  className="hover:text-white transition-colors"
                >
                  Fashion & Footwear
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/category/home', 'home')}
                  className="hover:text-white transition-colors"
                >
                  Home & Kitchen
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/category/beauty', 'beauty')}
                  className="hover:text-white transition-colors"
                >
                  Beauty & Personal Care
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/category/accessories', 'accessories')}
                  className="hover:text-white transition-colors"
                >
                  Daily Accessories
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Legal & Policies */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">
              Legal & Trust
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <button
                  onClick={() => onNavigate('/affiliate-disclosure')}
                  className="text-pink-400 font-semibold hover:text-pink-300 transition-colors flex items-center gap-1.5"
                >
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>Affiliate Disclosure</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/privacy-policy')}
                  className="hover:text-white transition-colors"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('/terms')}
                  className="hover:text-white transition-colors"
                >
                  Terms & Conditions
                </button>
              </li>
              <li>
                <span className="text-zinc-400 text-xs block pt-2">
                  Editorial Independence Guarantee: We never accept paid reviews for positive ratings.
                </span>
              </li>
            </ul>
          </div>

        </div>

        {/* Affiliate Disclaimer Callout Box */}
        <div className="my-8 p-4 rounded-2xl bg-zinc-900 border border-zinc-800 text-zinc-400 text-xs leading-relaxed">
          <div className="flex items-start gap-3">
            <span className="text-base flex-shrink-0">⚖️</span>
            <div>
              <strong className="text-zinc-200 block mb-1">
                Mandatory Affiliate & Transparency Disclosure:
              </strong>
              <p>
                {BRAND_CONFIG.affiliateDisclosureText}
              </p>
              <p className="mt-1 text-[11px] text-zinc-400">
                Prices, product availability, and promotional discounts on Amazon, Flipkart, Myntra, and Meesho are accurate as of the date/time indicated and are subject to change. Any price and availability information displayed on the merchant platform at the time of purchase will apply to the purchase of this product.
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Copyright & Credits */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-400 pt-4 border-t border-zinc-900">
          <p>© {currentYear} JL Choices. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Made with <Heart className="w-3 h-3 text-red-500 fill-red-500" /> for Indian shoppers
          </p>
        </div>

      </div>
    </footer>
  );
};
