import React from 'react';
import { CATEGORIES } from '../data/products';
import { CategorySlug } from '../types';
import {
  Flame,
  BadgePercent,
  Smartphone,
  Shirt,
  Home,
  Sparkles,
  Watch,
  Crown,
  ArrowRight,
  TrendingUp,
  Zap,
} from 'lucide-react';

interface CategorySectionProps {
  selectedCategory: string;
  onSelectCategory: (categorySlug: CategorySlug | 'all') => void;
}

interface CategoryStyleConfig {
  icon: React.ComponentType<{ className?: string }>;
  gradient: string;
  badge?: string;
  badgeClass?: string;
  subtitle: string;
  isSpecial?: boolean;
}

const CATEGORY_STYLES: Record<string, CategoryStyleConfig> = {
  trending: {
    icon: Flame,
    gradient: 'from-orange-500 via-rose-500 to-pink-500',
    badge: '🔥 HOT',
    badgeClass: 'bg-gradient-to-r from-orange-500 to-pink-500 text-white shadow-2xs',
    subtitle: 'Viral Finds',
    isSpecial: true,
  },
  deals: {
    icon: BadgePercent,
    gradient: 'from-pink-500 to-purple-600',
    badge: 'UP TO 70%',
    badgeClass: 'bg-pink-100 text-pink-700 border border-pink-200/80',
    subtitle: 'Price Drops',
  },
  gadgets: {
    icon: Smartphone,
    gradient: 'from-blue-500 to-indigo-600',
    badge: 'SMART',
    badgeClass: 'bg-blue-100 text-blue-700 border border-blue-200/80',
    subtitle: 'Audio & Tech',
  },
  fashion: {
    icon: Shirt,
    gradient: 'from-amber-500 to-orange-600',
    badge: 'TRENDY',
    badgeClass: 'bg-amber-100 text-amber-800 border border-amber-200/80',
    subtitle: 'Style & Fits',
  },
  home: {
    icon: Home,
    gradient: 'from-emerald-500 to-teal-600',
    badge: 'DECOR',
    badgeClass: 'bg-emerald-100 text-emerald-800 border border-emerald-200/80',
    subtitle: 'Living & Decor',
  },
  beauty: {
    icon: Sparkles,
    gradient: 'from-rose-500 to-pink-600',
    badge: 'GLOW UP',
    badgeClass: 'bg-rose-100 text-rose-800 border border-rose-200/80',
    subtitle: 'Skin & Care',
  },
  accessories: {
    icon: Watch,
    gradient: 'from-purple-500 to-violet-600',
    badge: 'ESSENTIAL',
    badgeClass: 'bg-purple-100 text-purple-800 border border-purple-200/80',
    subtitle: 'Daily Gear',
  },
  'top-picks': {
    icon: Crown,
    gradient: 'from-amber-400 via-orange-500 to-yellow-500',
    badge: '★ 4.8+',
    badgeClass: 'bg-amber-100 text-amber-900 border border-amber-200/80',
    subtitle: 'Top Rated',
  },
};

const TRENDING_QUICK_PICKS = [
  { label: 'ANC Wireless Earbuds', category: 'gadgets' as const, badge: '48% Off' },
  { label: 'Casual Shoulder Bag', category: 'fashion' as const, badge: '53% Off' },
  { label: 'Smart LED Desk Lamp', category: 'gadgets' as const, badge: '47% Off' },
  { label: 'Vitamin C Glow Serum', category: 'beauty' as const, badge: '38% Off' },
  { label: 'Insulated Water Bottle', category: 'accessories' as const, badge: '42% Off' },
  { label: 'Kitchen Storage Organizer', category: 'home' as const, badge: '50% Off' },
];

export const CategorySection: React.FC<CategorySectionProps> = ({
  selectedCategory,
  onSelectCategory,
}) => {
  return (
    <section className="py-12 sm:py-16 bg-[#FFFDF9] border-b border-zinc-200/60" id="categories-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with Trending Radar Pill */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-50 border border-orange-200/80 text-orange-700 text-xs font-bold mb-3 shadow-2xs">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500"></span>
              </span>
              <span>LIVE TRENDING RADAR</span>
              <span className="text-orange-300">•</span>
              <span className="text-zinc-600 font-medium">Real-Time Price & Popularity Tracker</span>
            </div>
            
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-zinc-900 tracking-tight">
              Shop by Category &{' '}
              <span className="bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 bg-clip-text text-transparent">
                Trending Drops
              </span>
            </h2>
            <p className="text-xs sm:text-sm text-zinc-600 font-medium mt-1.5 max-w-xl">
              Curated collections across Amazon, Flipkart, Myntra & Meesho verified for quality and highest discounts.
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 self-start md:self-auto">
            <button
              id="cat-btn-trending-filter"
              onClick={() => onSelectCategory('trending')}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-orange-500 to-pink-500 text-white text-xs font-bold shadow-xs hover:shadow-md hover:brightness-105 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Flame className="w-3.5 h-3.5" />
              <span>Trending Only</span>
            </button>
            <button
              id="cat-btn-view-all"
              onClick={() => onSelectCategory('all')}
              className="px-3.5 py-2 rounded-xl bg-white border border-zinc-200 hover:border-zinc-300 text-zinc-700 hover:text-zinc-900 text-xs font-bold shadow-2xs hover:shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span>View All Finds</span>
              <ArrowRight className="w-3.5 h-3.5 text-zinc-400" />
            </button>
          </div>
        </div>

        {/* Unique Bento Category Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4">
          {CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            const style = CATEGORY_STYLES[cat.id] || {
              icon: Sparkles,
              gradient: 'from-orange-500 to-pink-500',
              subtitle: 'Collection',
            };
            const IconComponent = style.icon;

            return (
              <button
                key={cat.id}
                id={`cat-card-${cat.id}`}
                onClick={() => onSelectCategory(cat.id)}
                className={`group relative flex flex-col items-center text-center p-3.5 sm:p-4 rounded-2xl border transition-all duration-300 cursor-pointer overflow-hidden ${
                  isSelected
                    ? 'bg-white border-pink-500 shadow-lg ring-2 ring-pink-500/20 -translate-y-1.5'
                    : style.isSpecial
                    ? 'bg-gradient-to-b from-orange-50/80 via-white to-white border-orange-200/90 hover:border-orange-400 hover:shadow-lg hover:-translate-y-1'
                    : 'bg-white hover:bg-white border-zinc-200/80 hover:border-orange-300 hover:shadow-md hover:-translate-y-1'
                }`}
              >
                {/* Special Highlight Ribbon for Trending */}
                {style.isSpecial && (
                  <div className="absolute top-0 right-0 w-12 h-12 overflow-hidden pointer-events-none">
                    <div className="bg-gradient-to-r from-orange-500 to-pink-500 text-[8px] font-black text-white text-center py-0.5 w-[70px] absolute top-[8px] -right-[18px] rotate-45 shadow-2xs">
                      HOT
                    </div>
                  </div>
                )}

                {/* Micro Badge */}
                {style.badge && (
                  <span
                    className={`text-[9px] font-bold px-2 py-0.5 rounded-full mb-2 ${
                      style.badgeClass || 'bg-zinc-100 text-zinc-600'
                    }`}
                  >
                    {style.badge}
                  </span>
                )}

                {/* Icon Capsule with Custom Gradient */}
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center text-white mb-2 shadow-sm transition-all duration-300 group-hover:scale-110 group-hover:rotate-3 bg-gradient-to-tr ${style.gradient}`}
                >
                  <IconComponent className="w-5 h-5 text-white" />
                </div>

                {/* Category Name */}
                <span
                  className={`text-xs sm:text-sm font-black tracking-tight line-clamp-1 ${
                    isSelected
                      ? 'text-pink-600'
                      : style.isSpecial
                      ? 'text-orange-950 group-hover:text-orange-600'
                      : 'text-zinc-900 group-hover:text-orange-600'
                  }`}
                >
                  {cat.name}
                </span>

                {/* Subtitle / Vibe */}
                <span className="text-[10px] font-medium text-zinc-600 line-clamp-1 mt-0.5">
                  {style.subtitle}
                </span>

                {/* Find Count Pill */}
                <div className="mt-2.5 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-zinc-100/80 text-[10px] font-bold text-zinc-600 group-hover:bg-orange-50 group-hover:text-orange-700 transition-colors">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span>{cat.count} finds</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Real-Time Trending Search Pills Strip */}
        <div className="mt-8 pt-6 border-t border-zinc-200/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs font-bold text-zinc-800">
            <span className="w-6 h-6 rounded-lg bg-orange-100 flex items-center justify-center text-orange-600">
              <Zap className="w-3.5 h-3.5 fill-current" />
            </span>
            <span>Trending Searches Right Now:</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {TRENDING_QUICK_PICKS.map((item) => (
              <button
                key={item.label}
                id={`trending-pill-${item.category}`}
                onClick={() => onSelectCategory(item.category)}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-white hover:bg-orange-50/80 border border-zinc-200 hover:border-orange-300 text-zinc-700 hover:text-orange-800 shadow-2xs hover:shadow-xs transition-all cursor-pointer group"
              >
                <span>{item.label}</span>
                <span className="text-[10px] font-bold text-orange-600 bg-orange-100/90 px-1.5 py-0.2 rounded-full group-hover:bg-orange-200/80 transition-colors">
                  {item.badge}
                </span>
              </button>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};

