import React, { useState } from 'react';
import { ArrowLeft, ShieldCheck, Mail, Send, CheckCircle2, FileText, Lock, Award, Heart, Instagram, Youtube, Facebook, Linkedin, ExternalLink } from 'lucide-react';
import { BRAND_CONFIG } from '../config/brand';
import { Logo } from './Logo';

interface PageProps {
  onBack: () => void;
}

// 1. AFFILIATE DISCLOSURE PAGE
export const AffiliateDisclosurePage: React.FC<PageProps> = ({ onBack }) => {
  return (
    <div className="py-12 bg-[#FFFDF9] min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-zinc-200 text-xs font-bold text-zinc-700 hover:bg-zinc-50 mb-6 shadow-2xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>

        <div className="bg-white rounded-3xl border border-zinc-200/80 p-6 sm:p-10 shadow-lg">
          
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-pink-100 text-pink-700 text-xs font-bold mb-4">
            <ShieldCheck className="w-4 h-4 text-pink-600" />
            <span>Ethical Standards & Transparency</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-black text-zinc-900 tracking-tight mb-4">
            Affiliate Disclosure
          </h1>
          <p className="text-sm text-zinc-500 mb-8 pb-6 border-b border-zinc-100">
            Last Updated: September 2026 • In compliance with Indian Advertising Standards Council (ASCI) and FTC guidelines.
          </p>

          <div className="prose prose-zinc max-w-none text-zinc-700 text-sm leading-relaxed space-y-6">
            
            <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 text-amber-950 font-medium">
              <strong>The Short Version:</strong> {BRAND_CONFIG.affiliateDisclosureText}
            </div>

            <h3 className="text-lg font-bold text-zinc-900">1. What is an Affiliate Link?</h3>
            <p>
              An affiliate link is a special tracking URL provided by merchant networks (including Amazon Associates, Flipkart Affiliate Program, EarnKaro, Myntra, and Meesho). When you click on a product link on JL Choices and proceed to make a purchase, the merchant recognizes that you came from our website and may award us a small percentage of the sale as a referral fee.
            </p>

            <h3 className="text-lg font-bold text-zinc-900">2. Does this affect the price you pay?</h3>
            <p>
              <strong>No, absolutely not.</strong> You will pay the exact same price (or lower, if our link points to a promotional coupon or limited-time deal) as you would if you visited Amazon, Flipkart, Myntra, or Meesho directly. The commission is paid entirely by the retailer out of their marketing budget.
            </p>

            <h3 className="text-lg font-bold text-zinc-900">3. Our Editorial & Curation Philosophy</h3>
            <p>
              At JL Choices (<strong>Better Finds • Smarter Choices</strong>), our top priority is helping Indian consumers discover genuine value. We follow strict editorial principles:
            </p>
            <ul className="list-disc pl-5 space-y-1.5">
              <li><strong>Zero Fake Reviews:</strong> We never manufacture artificial praise or publish fabricated customer testimonials.</li>
              <li><strong>Zero False Discounts:</strong> Discount percentages shown on JL Choices reflect real price differences against maximum retail prices (MRP) on merchant pages.</li>
              <li><strong>Independent Selection:</strong> Products are selected by our curation team based on genuine utility, aesthetics, verified user ratings (minimum 4.0+ stars with credible sample sizes), and budget friendliness. Retailers cannot pay for placement without transparent sponsored labeling.</li>
            </ul>

            <h3 className="text-lg font-bold text-zinc-900">4. Marketplace Trademarks</h3>
            <p>
              Amazon and the Amazon logo are trademarks of Amazon.com, Inc. or its affiliates. Flipkart, Myntra, and Meesho logos and trademarks belong to their respective corporate entities. JL Choices is an independent product discovery website and does not represent itself as an official branch or joint venture of any marketplace.
            </p>

            <h3 className="text-lg font-bold text-zinc-900">5. Questions & Feedback</h3>
            <p>
              If you have any questions regarding our affiliate relationships or wish to report a broken deal, please contact us at <a href={`mailto:${BRAND_CONFIG.supportEmail}`} className="text-pink-600 font-bold underline">{BRAND_CONFIG.supportEmail}</a>.
            </p>

          </div>

        </div>

      </div>
    </div>
  );
};

// 2. ABOUT US PAGE
export const AboutPage: React.FC<PageProps> = ({ onBack }) => {
  return (
    <div className="py-12 bg-[#FFFDF9] min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-zinc-200 text-xs font-bold text-zinc-700 hover:bg-zinc-50 mb-6 shadow-2xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>

        <div className="bg-white rounded-3xl border border-zinc-200/80 p-6 sm:p-10 shadow-lg">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 mb-6 pb-6 border-b border-zinc-100">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-orange-100 text-orange-700 text-xs font-bold mb-4">
                <Award className="w-4 h-4 text-orange-600" />
                <span>Our Story & Mission</span>
              </div>

              <h1 className="text-3xl sm:text-4xl font-black text-zinc-900 tracking-tight mb-2">
                About JL Choices
              </h1>
              <p className="text-base font-semibold text-zinc-600">
                Better Finds • Smarter Choices — Curating the best of Indian e-commerce.
              </p>
            </div>

            <div className="flex-shrink-0 self-center sm:self-auto">
              <Logo size="lg" />
            </div>
          </div>

          <div className="space-y-6 text-sm text-zinc-700 leading-relaxed">
            <p>
              Every single day, millions of products are uploaded across Amazon, Flipkart, Myntra, and Meesho. Yet finding genuinely durable, aesthetically pleasing, and budget-friendly goods feels harder than ever. Cluttered search results, sponsored ads, and duplicate listings waste valuable hours.
            </p>

            <p>
              <strong>JL Choices</strong> was created with a single purpose: to cut through the noise and curate only what is genuinely worth buying.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 my-8">
              <div className="p-4 rounded-2xl bg-orange-50/60 border border-orange-100">
                <div className="text-2xl font-black text-orange-600 mb-1">10,000+</div>
                <div className="text-xs font-bold text-zinc-900">Products Analyzed</div>
                <div className="text-[11px] text-zinc-500 mt-1">We inspect customer reviews, seller track records, and return rates.</div>
              </div>
              <div className="p-4 rounded-2xl bg-pink-50/60 border border-pink-100">
                <div className="text-2xl font-black text-pink-600 mb-1">4 Stores</div>
                <div className="text-xs font-bold text-zinc-900">Single Central Feed</div>
                <div className="text-[11px] text-zinc-500 mt-1">Amazon, Flipkart, Myntra, and Meesho deals in one place.</div>
              </div>
              <div className="p-4 rounded-2xl bg-purple-50/60 border border-purple-100">
                <div className="text-2xl font-black text-purple-600 mb-1">100% Free</div>
                <div className="text-xs font-bold text-zinc-900">For Shoppers</div>
                <div className="text-[11px] text-zinc-500 mt-1">No subscriptions, no hidden paywalls, completely free forever.</div>
              </div>
            </div>

            <h3 className="text-lg font-bold text-zinc-900">How We Pick Products</h3>
            <p>
              We evaluate products based on four fundamental pillars:
            </p>
            <ol className="list-decimal pl-5 space-y-2">
              <li><strong>Real Utility:</strong> Does this solve a genuine problem in your home, work desk, or wardrobe?</li>
              <li><strong>Price-to-Value Ratio:</strong> Is this legitimately a smart bargain compared to alternative options?</li>
              <li><strong>Quality Verification:</strong> Does the product have a consistent track record of 4+ star ratings from verified Indian buyers?</li>
              <li><strong>Reliable Fulfillment:</strong> Can it be delivered reliably with official marketplace return protections?</li>
            </ol>

            {/* Official Social Media Channels */}
            <div className="mt-8 pt-6 border-t border-zinc-100">
              <h3 className="text-base font-bold text-zinc-900 mb-3">Connect With Us</h3>
              <p className="text-xs text-zinc-500 mb-4">
                Follow JL Choices on our official social media channels for real-time deal alerts, unboxing reels, and trending picks:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <a
                  id="about-social-instagram"
                  href={BRAND_CONFIG.socials.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-2xl border border-pink-100 bg-pink-50/50 hover:bg-pink-100/60 transition-colors text-zinc-800 group"
                >
                  <div className="w-9 h-9 rounded-xl bg-pink-500 text-white flex items-center justify-center shadow-xs">
                    <Instagram className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-zinc-900 flex items-center gap-1">
                      Instagram <ExternalLink className="w-3 h-3 text-zinc-400 group-hover:text-pink-600" />
                    </div>
                    <div className="text-[11px] text-zinc-500 truncate">@jlchoices</div>
                  </div>
                </a>

                <a
                  id="about-social-youtube"
                  href={BRAND_CONFIG.socials.youtube}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-2xl border border-red-100 bg-red-50/50 hover:bg-red-100/60 transition-colors text-zinc-800 group"
                >
                  <div className="w-9 h-9 rounded-xl bg-red-600 text-white flex items-center justify-center shadow-xs">
                    <Youtube className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-zinc-900 flex items-center gap-1">
                      YouTube <ExternalLink className="w-3 h-3 text-zinc-400 group-hover:text-red-600" />
                    </div>
                    <div className="text-[11px] text-zinc-500 truncate">@JLChoices</div>
                  </div>
                </a>

                <a
                  id="about-social-linkedin"
                  href={BRAND_CONFIG.socials.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-2xl border border-sky-100 bg-sky-50/50 hover:bg-sky-100/60 transition-colors text-zinc-800 group"
                >
                  <div className="w-9 h-9 rounded-xl bg-sky-600 text-white flex items-center justify-center shadow-xs">
                    <Linkedin className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-zinc-900 flex items-center gap-1">
                      LinkedIn <ExternalLink className="w-3 h-3 text-zinc-400 group-hover:text-sky-600" />
                    </div>
                    <div className="text-[11px] text-zinc-500 truncate">JL Choices</div>
                  </div>
                </a>

                <a
                  id="about-social-facebook"
                  href={BRAND_CONFIG.socials.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-2xl border border-blue-100 bg-blue-50/50 hover:bg-blue-100/60 transition-colors text-zinc-800 group"
                >
                  <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                    <Facebook className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-zinc-900 flex items-center gap-1">
                      Facebook <ExternalLink className="w-3 h-3 text-zinc-400 group-hover:text-blue-600" />
                    </div>
                    <div className="text-[11px] text-zinc-500 truncate">JL Choices Page</div>
                  </div>
                </a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

// 3. CONTACT US PAGE
export const ContactPage: React.FC<PageProps> = ({ onBack }) => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', subject: 'Product Suggestion', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="py-12 bg-[#FFFDF9] min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-zinc-200 text-xs font-bold text-zinc-700 hover:bg-zinc-50 mb-6 shadow-2xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>

        <div className="bg-white rounded-3xl border border-zinc-200/80 p-6 sm:p-10 shadow-lg">
          
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-purple-100 text-purple-700 text-xs font-bold mb-4">
            <Mail className="w-4 h-4 text-purple-600" />
            <span>We'd Love To Hear From You</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-black text-zinc-900 tracking-tight mb-2">
            Contact JL Choices
          </h1>
          <p className="text-sm text-zinc-500 mb-8 pb-6 border-b border-zinc-100">
            Have a product you'd like us to review, found an expired deal, or want to collaborate? Send us a message.
          </p>

          {submitted ? (
            <div className="p-8 rounded-2xl bg-emerald-50 border border-emerald-200 text-center">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto mb-3" />
              <h3 className="text-lg font-bold text-zinc-900 mb-1">Message Received!</h3>
              <p className="text-xs sm:text-sm text-zinc-600 mb-4">
                Thank you for reaching out. The JL Choices team will review your note and respond within 24–48 hours.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-zinc-900 text-white"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-1.5">
                  Your Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rahul Sharma"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-zinc-200 text-sm focus:outline-none focus:ring-2 focus:ring-pink-500 bg-zinc-50/50"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-1.5">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-zinc-200 text-sm focus:outline-none focus:ring-2 focus:ring-pink-500 bg-zinc-50/50"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-1.5">
                  Subject
                </label>
                <select
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-zinc-200 text-sm focus:outline-none focus:ring-2 focus:ring-pink-500 bg-zinc-50/50 cursor-pointer"
                >
                  <option value="Product Suggestion">Suggest a Great Deal / Product</option>
                  <option value="Expired Deal Report">Report an Expired Deal or Price Change</option>
                  <option value="Brand Partnership">Brand Partnership / Affiliate Collaboration</option>
                  <option value="General Inquiry">General Feedback or Question</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-700 uppercase tracking-wider mb-1.5">
                  Your Message
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Tell us what's on your mind..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-zinc-200 text-sm focus:outline-none focus:ring-2 focus:ring-pink-500 bg-zinc-50/50"
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 hover:from-orange-600 hover:via-pink-600 hover:to-purple-700 shadow-md shadow-pink-500/20 active:scale-98 transition-all flex items-center justify-center gap-2"
              >
                <span>Send Message</span>
                <Send className="w-4 h-4" />
              </button>
            </form>
          )}

          <div className="mt-8 pt-6 border-t border-zinc-100 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-zinc-500 mb-6">
            <span>Direct inquiries: <strong>{BRAND_CONFIG.supportEmail}</strong></span>
            <span>Response time: ~24 business hours</span>
          </div>

          {/* Social Channels on Contact Page */}
          <div className="pt-4 border-t border-zinc-100">
            <h4 className="text-xs font-bold text-zinc-800 uppercase tracking-wider mb-3">
              Official Social Channels
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <a
                id="contact-social-instagram"
                href={BRAND_CONFIG.socials.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 p-2.5 rounded-xl border border-zinc-200/80 bg-zinc-50 hover:bg-pink-50 hover:border-pink-200 transition-colors group"
              >
                <Instagram className="w-4 h-4 text-pink-600" />
                <span className="text-xs font-semibold text-zinc-700 group-hover:text-pink-700">Instagram</span>
              </a>
              <a
                id="contact-social-youtube"
                href={BRAND_CONFIG.socials.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 p-2.5 rounded-xl border border-zinc-200/80 bg-zinc-50 hover:bg-red-50 hover:border-red-200 transition-colors group"
              >
                <Youtube className="w-4 h-4 text-red-600" />
                <span className="text-xs font-semibold text-zinc-700 group-hover:text-red-700">YouTube</span>
              </a>
              <a
                id="contact-social-linkedin"
                href={BRAND_CONFIG.socials.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 p-2.5 rounded-xl border border-zinc-200/80 bg-zinc-50 hover:bg-sky-50 hover:border-sky-200 transition-colors group"
              >
                <Linkedin className="w-4 h-4 text-sky-600" />
                <span className="text-xs font-semibold text-zinc-700 group-hover:text-sky-700">LinkedIn</span>
              </a>
              <a
                id="contact-social-facebook"
                href={BRAND_CONFIG.socials.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 p-2.5 rounded-xl border border-zinc-200/80 bg-zinc-50 hover:bg-blue-50 hover:border-blue-200 transition-colors group"
              >
                <Facebook className="w-4 h-4 text-blue-600" />
                <span className="text-xs font-semibold text-zinc-700 group-hover:text-blue-700">Facebook</span>
              </a>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

// 4. PRIVACY POLICY PAGE
export const PrivacyPolicyPage: React.FC<PageProps> = ({ onBack }) => {
  return (
    <div className="py-12 bg-[#FFFDF9] min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-zinc-200 text-xs font-bold text-zinc-700 hover:bg-zinc-50 mb-6 shadow-2xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>

        <div className="bg-white rounded-3xl border border-zinc-200/80 p-6 sm:p-10 shadow-lg prose prose-zinc max-w-none text-zinc-700 text-sm leading-relaxed">
          <h1 className="text-3xl font-black text-zinc-900 tracking-tight mb-2">Privacy Policy</h1>
          <p className="text-xs text-zinc-400 mb-6">Effective Date: September 2026</p>

          <p>
            At JL Choices, we respect your personal privacy. We do not require you to create an account or provide payment card information on this site.
          </p>

          <h3 className="text-base font-bold text-zinc-900 mt-6">Information We Collect</h3>
          <p>
            When you subscribe to our deals newsletter or submit our contact form, we collect only the email address and name you voluntarily submit. We do not sell or rent your personal information to any third parties.
          </p>

          <h3 className="text-base font-bold text-zinc-900 mt-6">Cookies & Outbound Links</h3>
          <p>
            When you click an outbound link to Amazon, Flipkart, Myntra, or Meesho, those third-party merchants may place a tracking cookie on your browser in accordance with their respective privacy policies to track affiliate referral credit.
          </p>

          <h3 className="text-base font-bold text-zinc-900 mt-6">Contact</h3>
          <p>
            Questions regarding this privacy policy may be sent to <a href={`mailto:${BRAND_CONFIG.supportEmail}`} className="text-pink-600 underline font-semibold">{BRAND_CONFIG.supportEmail}</a>.
          </p>
        </div>
      </div>
    </div>
  );
};

// 5. TERMS & CONDITIONS PAGE
export const TermsPage: React.FC<PageProps> = ({ onBack }) => {
  return (
    <div className="py-12 bg-[#FFFDF9] min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-zinc-200 text-xs font-bold text-zinc-700 hover:bg-zinc-50 mb-6 shadow-2xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>

        <div className="bg-white rounded-3xl border border-zinc-200/80 p-6 sm:p-10 shadow-lg prose prose-zinc max-w-none text-zinc-700 text-sm leading-relaxed">
          <h1 className="text-3xl font-black text-zinc-900 tracking-tight mb-2">Terms & Conditions</h1>
          <p className="text-xs text-zinc-400 mb-6">Effective Date: September 2026</p>

          <p>
            By accessing and using JL Choices, you accept and agree to be bound by the terms and provision of this agreement.
          </p>

          <h3 className="text-base font-bold text-zinc-900 mt-6">Affiliate Links & Merchant Transactions</h3>
          <p>
            JL Choices is an informational and product curation service. All purchases, returns, deliveries, warranties, and payment customer service are handled exclusively by the corresponding merchant (Amazon, Flipkart, Myntra, or Meesho). JL Choices does not process payments or ship products.
          </p>

          <h3 className="text-base font-bold text-zinc-900 mt-6">Price & Availability Accuracy</h3>
          <p>
            While we strive to update prices promptly, online retailers adjust prices and promotional stocks dynamically. In the event of a discrepancy between JL Choices and the retailer's checkout page, the retailer's checkout price governs.
          </p>
        </div>
      </div>
    </div>
  );
};
