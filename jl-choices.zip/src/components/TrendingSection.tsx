import React, { useRef } from 'react';
import { Product } from '../types';
import { Flame, ChevronLeft, ChevronRight, ExternalLink, Star } from 'lucide-react';

interface TrendingSectionProps {
  products: Product[];
  onOpenDetails: (product: Product) => void;
}

export const TrendingSection: React.FC<TrendingSectionProps> = ({
  products,
  onOpenDetails,
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const trendingProducts = products.filter((p) => p.isTrending);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = direction === 'left' ? -340 : 340;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <section className="py-12 bg-gradient-to-b from-orange-50/30 via-pink-50/20 to-white border-t border-zinc-200/60" id="trending-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-orange-600 uppercase tracking-wider mb-1">
              <Flame className="w-3.5 h-3.5 text-orange-500 animate-bounce" />
              <span>Viral & Fast Selling</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-zinc-900 tracking-tight">
              🔥 Trending Right Now
            </h2>
          </div>

          {/* Desktop Arrow Navigation */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => scroll('left')}
              className="p-2.5 rounded-full bg-white border border-zinc-200 shadow-2xs hover:bg-zinc-50 text-zinc-700 hover:text-zinc-900 transition-colors"
              aria-label="Scroll left"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="p-2.5 rounded-full bg-white border border-zinc-200 shadow-2xs hover:bg-zinc-50 text-zinc-700 hover:text-zinc-900 transition-colors"
              aria-label="Scroll right"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Horizontal Scrolling Products Row */}
        <div
          ref={scrollRef}
          className="flex gap-4 sm:gap-5 overflow-x-auto pb-4 pt-1 no-scrollbar scroll-smooth snap-x snap-mandatory"
        >
          {trendingProducts.map((product) => (
            <div
              key={`trending-${product.id}`}
              onClick={() => onOpenDetails(product)}
              className="snap-start flex-shrink-0 w-64 sm:w-72 bg-white rounded-2xl border border-zinc-200/80 shadow-xs hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col group cursor-pointer"
            >
              {/* Product Image */}
              <div className="relative aspect-square w-full bg-zinc-50 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                
                {/* Discount Badge */}
                <div className="absolute top-2.5 left-2.5 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-black text-xs px-2.5 py-1 rounded-lg shadow-sm">
                  {product.discount}% OFF
                </div>

                {/* Marketplace Tag */}
                <div className="absolute bottom-2.5 left-2.5 bg-white/95 backdrop-blur-xs text-zinc-900 text-[11px] font-bold px-2 py-0.5 rounded-md border border-zinc-200 shadow-2xs">
                  {product.marketplace}
                </div>
              </div>

              {/* Product Info */}
              <div className="p-4 flex flex-col flex-1">
                {/* Rating */}
                <div className="flex items-center gap-1 text-xs font-bold text-amber-500 mb-1">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>{product.rating}</span>
                  <span className="text-zinc-400 text-[11px] font-normal">
                    ({product.reviewCount.toLocaleString()})
                  </span>
                </div>

                {/* Name */}
                <h3 className="font-bold text-sm text-zinc-900 line-clamp-1 group-hover:text-pink-600 transition-colors mb-2">
                  {product.name}
                </h3>

                {/* Price */}
                <div className="mt-auto flex items-baseline gap-2 mb-3">
                  <span className="text-lg font-black text-zinc-900">
                    ₹{product.price.toLocaleString('en-IN')}
                  </span>
                  <span className="text-xs text-zinc-400 line-through">
                    ₹{product.originalPrice.toLocaleString('en-IN')}
                  </span>
                </div>

                {/* View Deal Button */}
                <a
                  href={product.affiliateUrl}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  onClick={(e) => e.stopPropagation()}
                  className="w-full py-2 px-3 rounded-xl text-xs font-extrabold text-white bg-zinc-900 hover:bg-gradient-to-r hover:from-orange-500 hover:to-pink-600 transition-all text-center flex items-center justify-center gap-1.5 active:scale-95 shadow-xs"
                >
                  <span>View Deal</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
