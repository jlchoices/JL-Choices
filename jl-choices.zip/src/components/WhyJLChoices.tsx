import React from 'react';
import { Search, DollarSign, Flame, Zap, ShieldCheck } from 'lucide-react';

export const WhyJLChoices: React.FC = () => {
  const features = [
    {
      icon: <Search className="w-6 h-6 text-orange-500" />,
      bg: 'bg-orange-50 border-orange-100',
      title: 'Curated Finds',
      description: 'We discover interesting products worth checking out, filtering through tens of thousands of items to find genuine quality.',
    },
    {
      icon: <DollarSign className="w-6 h-6 text-emerald-500" />,
      bg: 'bg-emerald-50 border-emerald-100',
      title: 'Budget Friendly',
      description: 'Find products across different price ranges with transparent price history and real savings per rupee.',
    },
    {
      icon: <Flame className="w-6 h-6 text-pink-500" />,
      bg: 'bg-pink-50 border-pink-100',
      title: 'Trending Products',
      description: 'Stay updated with products people are talking about across social media, reviews, and community forums.',
    },
    {
      icon: <Zap className="w-6 h-6 text-purple-500" />,
      bg: 'bg-purple-50 border-purple-100',
      title: 'Easy Shopping',
      description: 'Discover products in seconds and go directly to the marketplace with secure 1-click checkout.',
    },
  ];

  return (
    <section className="py-14 bg-[#FFFDF9] border-t border-zinc-200/60" id="why-jlchoices-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-xs font-bold mb-2">
            <span>Our Commitment</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-zinc-900 tracking-tight">
            Why JL Choices?
          </h2>
          <p className="text-sm text-zinc-600 mt-2">
            Built for smart shoppers who value their time and hard-earned money.
          </p>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-6 border border-zinc-200/80 shadow-xs hover:shadow-lg transition-all duration-200 flex flex-col items-start"
            >
              {/* Icon Container */}
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center border mb-4 ${item.bg}`}
              >
                {item.icon}
              </div>

              {/* Title */}
              <h3 className="text-lg font-bold text-zinc-900 mb-2">
                {item.title}
              </h3>

              {/* Description */}
              <p className="text-xs sm:text-sm text-zinc-600 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
