import React from 'react';
import { MARKETPLACES } from '../data/products';
import { ExternalLink, ArrowRight, ShieldCheck } from 'lucide-react';
import { MarketplaceType } from '../types';

interface MarketplaceSectionProps {
  onSelectMarketplace: (marketplace: MarketplaceType) => void;
}

export const MarketplaceSection: React.FC<MarketplaceSectionProps> = ({
  onSelectMarketplace,
}) => {
  return (
    <section className="py-14 bg-white border-t border-zinc-200/60" id="marketplace-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-bold mb-2">
            <span>Multi-Platform Discovery</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-zinc-900 tracking-tight">
            Shop From Your Favorite Platforms
          </h2>
          <p className="text-sm text-zinc-600 mt-2">
            We scan top Indian online marketplaces to bring you verified bargains in one centralized feed.
          </p>
        </div>

        {/* Four Marketplace Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {MARKETPLACES.map((mp) => (
            <div
              key={mp.id}
              className="group relative bg-[#FFFDF9] rounded-2xl border border-zinc-200/80 p-5 shadow-xs hover:shadow-xl hover:border-zinc-300 transition-all duration-300 flex flex-col justify-between"
            >
              {/* Top Accent Stripe */}
              <div
                className="absolute top-0 left-0 right-0 h-1.5 rounded-t-2xl"
                style={{ backgroundColor: mp.accentColor }}
              />

              <div>
                {/* Platform Badge & Title */}
                <div className="flex items-center justify-between mb-4 pt-1">
                  <span
                    className={`text-xs font-bold px-3 py-1 rounded-md border ${mp.badgeBg}`}
                  >
                    {mp.name}
                  </span>
                  <span className="text-[11px] font-semibold text-zinc-600">
                    Live Deals
                  </span>
                </div>

                {/* Tagline */}
                <h3 className="font-bold text-base text-zinc-900 mb-2 leading-snug">
                  {mp.tagline}
                </h3>

                {/* Description */}
                <p className="text-xs text-zinc-600 leading-relaxed mb-6">
                  {mp.description}
                </p>
              </div>

              {/* Action Button */}
              <div className="pt-4 border-t border-zinc-100">
                <button
                  id={`explore-mp-${mp.id.toLowerCase()}`}
                  onClick={() => onSelectMarketplace(mp.id)}
                  className="w-full py-2.5 px-3 rounded-xl text-xs font-bold text-zinc-800 bg-white border border-zinc-200 hover:border-zinc-300 hover:bg-zinc-50 shadow-2xs transition-all flex items-center justify-center gap-1.5 group-hover:bg-zinc-900 group-hover:text-white group-hover:border-zinc-900"
                >
                  <span>Explore {mp.name} Deals</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Trademark Disclaimer note */}
        <div className="mt-8 text-center">
          <p className="text-[11px] text-zinc-600 max-w-2xl mx-auto flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-zinc-600 flex-shrink-0" />
            <span>
              Amazon, Flipkart, Myntra, and Meesho are registered trademarks of their respective owners. JL Choices is an independent discovery platform.
            </span>
          </p>
        </div>

      </div>
    </section>
  );
};
