import React, { useState, useMemo } from 'react';
import { Product, CategorySlug } from '../types';
import { ProductCard } from './ProductCard';
import { Search, SlidersHorizontal, Sparkles, X, ArrowUpDown, Tag } from 'lucide-react';

interface ProductGridProps {
  products: Product[];
  selectedCategory: string;
  onSelectCategory: (categorySlug: CategorySlug | 'all') => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenDetails: (product: Product) => void;
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  selectedCategory,
  onSelectCategory,
  searchQuery,
  onSearchChange,
  onOpenDetails,
}) => {
  const [sortBy, setSortBy] = useState<'popular' | 'price-low' | 'price-high' | 'discount'>('popular');
  const [selectedMarketplace, setSelectedMarketplace] = useState<string>('all');

  const categoryPills: { id: CategorySlug | 'all'; label: string }[] = [
    { id: 'all', label: 'All Products' },
    { id: 'trending', label: '🔥 Trending' },
    { id: 'deals', label: '💰 Deals' },
    { id: 'gadgets', label: '📱 Gadgets' },
    { id: 'fashion', label: '👕 Fashion' },
    { id: 'home', label: '🏠 Home & Kitchen' },
    { id: 'beauty', label: '💄 Beauty' },
    { id: 'accessories', label: '🎧 Accessories' },
    { id: 'top-picks', label: '⭐ Top Picks' },
  ];

  // Filtering and sorting logic
  const filteredProducts = useMemo(() => {
    let list = [...products];

    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.shortDescription.toLowerCase().includes(q) ||
          p.marketplace.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.features.some((f) => f.toLowerCase().includes(q))
      );
    }

    // Category filter
    if (selectedCategory !== 'all') {
      if (selectedCategory === 'deals') {
        list = list.filter((p) => p.isDeal || p.discount >= 45);
      } else if (selectedCategory === 'trending') {
        list = list.filter((p) => p.isTrending);
      } else if (selectedCategory === 'top-picks') {
        list = list.filter((p) => p.isTopPick);
      } else {
        list = list.filter((p) => p.category === selectedCategory);
      }
    }

    // Marketplace filter
    if (selectedMarketplace !== 'all') {
      list = list.filter((p) => p.marketplace === selectedMarketplace);
    }

    // Sorting
    switch (sortBy) {
      case 'price-low':
        list.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        list.sort((a, b) => b.price - a.price);
        break;
      case 'discount':
        list.sort((a, b) => b.discount - a.discount);
        break;
      case 'popular':
      default:
        list.sort((a, b) => b.reviewCount - a.reviewCount);
        break;
    }

    return list;
  }, [products, searchQuery, selectedCategory, selectedMarketplace, sortBy]);

  return (
    <section className="py-12 bg-white border-t border-zinc-200/60" id="products-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-pink-600 uppercase tracking-wider mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>
                {selectedCategory === 'trending'
                  ? '⚡ Viral & Fast Selling Online'
                  : selectedCategory === 'deals'
                  ? '🔥 Top Discounted Deals'
                  : 'Verified Indian Marketplace Deals'}
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-zinc-900 tracking-tight flex items-center gap-2">
              <span>
                {selectedCategory === 'trending'
                  ? '🔥 Trending Finds Right Now'
                  : selectedCategory === 'deals'
                  ? '💰 Best Verified Deals'
                  : selectedCategory === 'gadgets'
                  ? '📱 Gadgets & Smart Tech'
                  : selectedCategory === 'fashion'
                  ? '👕 Fashion & Lifestyle'
                  : selectedCategory === 'home'
                  ? '🏠 Home & Kitchen Essentials'
                  : selectedCategory === 'beauty'
                  ? '💄 Beauty & Personal Care'
                  : selectedCategory === 'accessories'
                  ? '🎧 Daily Accessories & Gear'
                  : selectedCategory === 'top-picks'
                  ? '⭐ Top Editor Picks'
                  : "Today's Top Picks"}
              </span>
              <span className="text-sm font-semibold text-zinc-500 bg-zinc-100 px-2.5 py-0.5 rounded-full">
                {filteredProducts.length}
              </span>
            </h2>
          </div>

          {/* Quick Filters / Sorting Bar */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Marketplace filter pill */}
            <div className="flex items-center gap-1 bg-zinc-100 p-1 rounded-xl border border-zinc-200 text-xs">
              <span className="text-zinc-600 px-1 font-semibold hidden sm:inline">Store:</span>
              {['all', 'Amazon', 'Flipkart', 'Myntra', 'Meesho'].map((mp) => (
                <button
                  key={mp}
                  onClick={() => setSelectedMarketplace(mp)}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all text-xs ${
                    selectedMarketplace === mp
                      ? 'bg-white text-zinc-900 shadow-2xs'
                      : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  {mp === 'all' ? 'All Stores' : mp}
                </button>
              ))}
            </div>

            {/* Sorting Dropdown */}
            <div className="flex items-center gap-1.5 bg-zinc-100 px-3 py-1.5 rounded-xl border border-zinc-200 text-xs">
              <ArrowUpDown className="w-3.5 h-3.5 text-zinc-500" />
              <label htmlFor="sort-select" className="sr-only">Sort by</label>
              <select
                id="sort-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent font-bold text-zinc-800 focus:outline-none cursor-pointer"
              >
                <option value="popular">Popular</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="discount">Highest Discount</option>
              </select>
            </div>
          </div>
        </div>

        {/* Category Pills Row */}
        <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6 no-scrollbar">
          {categoryPills.map((pill) => {
            const isSelected = selectedCategory === pill.id;
            return (
              <button
                key={pill.id}
                id={`filter-pill-${pill.id}`}
                onClick={() => onSelectCategory(pill.id)}
                className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-150 flex-shrink-0 ${
                  isSelected
                    ? 'bg-zinc-900 text-white shadow-sm'
                    : 'bg-zinc-100/90 hover:bg-zinc-200/80 text-zinc-700'
                }`}
              >
                {pill.label}
              </button>
            );
          })}
        </div>

        {/* Active Search / Filter Status */}
        {(searchQuery || selectedCategory !== 'all' || selectedMarketplace !== 'all') && (
          <div className="mb-6 flex flex-wrap items-center justify-between gap-2 p-3 bg-pink-50/50 border border-pink-100 rounded-xl text-xs">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-pink-900">Active Filters:</span>
              {searchQuery && (
                <span className="inline-flex items-center gap-1 bg-white px-2.5 py-1 rounded-md text-pink-700 font-bold border border-pink-200">
                  Search: "{searchQuery}"
                  <button onClick={() => onSearchChange('')} className="hover:text-pink-950 font-bold">×</button>
                </span>
              )}
              {selectedCategory !== 'all' && (
                <span className="inline-flex items-center gap-1 bg-white px-2.5 py-1 rounded-md text-pink-700 font-bold border border-pink-200">
                  Category: {selectedCategory}
                  <button onClick={() => onSelectCategory('all')} className="hover:text-pink-950 font-bold">×</button>
                </span>
              )}
              {selectedMarketplace !== 'all' && (
                <span className="inline-flex items-center gap-1 bg-white px-2.5 py-1 rounded-md text-pink-700 font-bold border border-pink-200">
                  Store: {selectedMarketplace}
                  <button onClick={() => setSelectedMarketplace('all')} className="hover:text-pink-950 font-bold">×</button>
                </span>
              )}
            </div>

            <div className="flex items-center gap-3">
              <span className="text-zinc-600 font-medium">
                Showing <strong className="text-zinc-900">{filteredProducts.length}</strong> items
              </span>
              <button
                onClick={() => {
                  onSearchChange('');
                  onSelectCategory('all');
                  setSelectedMarketplace('all');
                }}
                className="text-pink-600 hover:text-pink-800 font-bold underline"
              >
                Reset All
              </button>
            </div>
          </div>
        )}

        {/* Product Cards Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onOpenDetails={onOpenDetails}
              />
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="text-center py-16 px-4 bg-zinc-50 rounded-2xl border border-dashed border-zinc-300">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-orange-100 flex items-center justify-center text-orange-600">
              <Search className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-zinc-900 mb-1">
              No matching products found
            </h3>
            <p className="text-xs sm:text-sm text-zinc-500 max-w-md mx-auto mb-6">
              We couldn't find any deals matching "{searchQuery}". Try searching for something else like "earbuds", "lamp", "handbag", or reset your filters.
            </p>
            <button
              onClick={() => {
                onSearchChange('');
                onSelectCategory('all');
                setSelectedMarketplace('all');
              }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-zinc-900 hover:bg-zinc-800 transition-colors"
            >
              <X className="w-4 h-4" />
              <span>Clear Search & Filters</span>
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
