import React, { useState } from 'react';
import { Mail, CheckCircle2, Sparkles, Send } from 'lucide-react';

export const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@') || !email.includes('.')) {
      setErrorMessage('Please enter a valid email address');
      return;
    }
    setErrorMessage('');
    setIsSubmitted(true);
  };

  return (
    <section className="py-14 bg-gradient-to-b from-white to-[#FFFDF9] border-t border-zinc-200/60" id="newsletter-section">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        
        <div className="bg-gradient-to-br from-zinc-900 via-zinc-800 to-zinc-950 rounded-3xl p-8 sm:p-12 text-white shadow-2xl relative overflow-hidden">
          
          {/* Subtle decorative glow */}
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-60 h-60 bg-gradient-to-br from-orange-500/20 via-pink-500/20 to-purple-500/20 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-60 h-60 bg-gradient-to-tr from-purple-500/20 to-yellow-500/15 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 max-w-xl mx-auto">
            {/* Tag */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-xs text-yellow-300 text-xs font-bold mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Weekly Handpicked Deals</span>
            </div>

            {/* Headline */}
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight mb-3">
              Get the Best Deals in Your Inbox
            </h2>

            {/* Text */}
            <p className="text-sm sm:text-base text-zinc-300 mb-8 leading-relaxed">
              Subscribe to receive our latest product finds, deals and shopping recommendations. No spam, ever.
            </p>

            {/* Form */}
            {isSubmitted ? (
              <div className="bg-emerald-500/20 border border-emerald-500/40 rounded-2xl p-5 text-emerald-200 flex items-center justify-center gap-3 animate-in fade-in duration-300">
                <CheckCircle2 className="w-6 h-6 text-emerald-400 flex-shrink-0" />
                <div className="text-left text-xs sm:text-sm">
                  <strong className="block text-white font-bold">You're on the list!</strong>
                  We'll send you our handpicked weekly shopping finds to <span className="text-emerald-300 underline">{email}</span>.
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2.5 max-w-md mx-auto">
                <div className="relative flex-1">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (errorMessage) setErrorMessage('');
                    }}
                    placeholder="Enter your email"
                    required
                    className="w-full pl-10 pr-4 py-3.5 rounded-xl text-sm bg-white/10 border border-white/20 text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:bg-white/15 transition-all"
                  />
                  <Mail className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>

                <button
                  type="submit"
                  className="px-6 py-3.5 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 hover:from-orange-600 hover:via-pink-600 hover:to-purple-700 shadow-md shadow-pink-500/20 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <span>Subscribe</span>
                  <Send className="w-4 h-4" />
                </button>
              </form>
            )}

            {errorMessage && (
              <p className="text-xs text-rose-400 mt-2 font-medium">
                {errorMessage}
              </p>
            )}

            <p className="text-[11px] text-zinc-400 mt-4">
              Join 12,000+ smart Indian shoppers. Unsubscribe anytime with 1 click.
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};
