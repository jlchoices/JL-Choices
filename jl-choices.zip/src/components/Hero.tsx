import React from 'react';
import { ArrowRight, Flame, TrendingUp, ShieldCheck, Sparkles, CheckCircle2 } from 'lucide-react';
import { Product } from '../types';
import { PRODUCTS } from '../data/products';

interface HeroProps {
  onExploreDeals: () => void;
  onExploreTrending: () => void;
  onOpenDetails?: (product: Product) => void;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreDeals,
  onExploreTrending,
  onOpenDetails,
}) => {
  const pEarbuds = PRODUCTS[0];
  const pLamp = PRODUCTS[1];
  const pBag = PRODUCTS[2];

  return (
    <section className="relative overflow-hidden bg-[#FFFDF9] pt-8 pb-16 lg:py-20 border-b border-zinc-200/50">
      {/* Decorative ambient background glows matching screenshot */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-bl from-amber-200/35 via-orange-100/25 to-transparent rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-0 left-0 w-[550px] h-[550px] bg-gradient-to-tr from-purple-200/25 via-pink-100/20 to-transparent rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Headlines & Call to Actions */}
          <div className="lg:col-span-6 xl:col-span-6 flex flex-col items-center text-center z-10 pt-2 sm:pt-0">
            {/* Top Interactive Deals & Highlights Bar */}
            <div className="flex flex-col items-center gap-2.5 mb-6">
              <button
                id="hero-live-deals-pill"
                onClick={onExploreDeals}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-orange-500/10 via-pink-500/10 to-purple-500/10 border border-orange-200/90 text-xs font-semibold text-zinc-800 shadow-2xs hover:border-orange-300 hover:shadow-xs transition-all group cursor-pointer"
              >
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500"></span>
                </span>
                <span className="font-bold text-orange-600">Fresh Deals Live</span>
                <span className="text-zinc-300 font-light">•</span>
                <span className="text-zinc-700">Explore Handpicked Finds Up to 70% Off</span>
                <ArrowRight className="w-3.5 h-3.5 text-orange-500 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <div className="flex flex-wrap items-center justify-center gap-2 text-[11px] font-semibold text-zinc-600">
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-orange-50 border border-orange-200/70 text-orange-700">
                  <Flame className="w-3 h-3 text-orange-500" />
                  Trending Daily
                </span>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-purple-50 border border-purple-200/70 text-purple-700">
                  <Sparkles className="w-3 h-3 text-purple-500" />
                  100% Curated Finds
                </span>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200/70 text-emerald-700">
                  <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                  Verified Prices
                </span>
              </div>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-zinc-900 tracking-tight leading-[1.1] mb-5">
              Better Finds.{' '}
              <span className="bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 bg-clip-text text-transparent">
                Smarter Choices.
              </span>
            </h1>

            {/* Subheading */}
            <p className="text-base sm:text-lg text-zinc-600 font-medium leading-relaxed max-w-xl mb-8 mx-auto">
              Discover trending products, amazing deals and budget-friendly finds from your favorite shopping platforms.
            </p>

            {/* Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3.5 mb-8 w-full sm:w-auto">
              <button
                id="hero-btn-explore-deals"
                onClick={onExploreDeals}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 hover:from-orange-600 hover:via-pink-600 hover:to-purple-700 shadow-md shadow-pink-500/20 hover:shadow-lg transition-all active:scale-98 cursor-pointer"
              >
                <Flame className="w-4 h-4 text-yellow-300" />
                <span>Explore Deals</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                id="hero-btn-trending-products"
                onClick={onExploreTrending}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm text-zinc-800 bg-white border border-zinc-300 hover:border-zinc-400 hover:bg-zinc-50 shadow-sm transition-all active:scale-98 cursor-pointer"
              >
                <TrendingUp className="w-4 h-4 text-purple-600" />
                <span>Trending Products</span>
              </button>
            </div>

            {/* Small Trust Text */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-2 text-xs text-zinc-500 pt-3 border-t border-zinc-200/60 w-full">
              <span className="font-semibold text-zinc-700 flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Trusted Finds From:
              </span>
              <div className="flex flex-wrap items-center justify-center gap-2 font-medium">
                <span className="px-2.5 py-1 rounded-md bg-white border border-zinc-200 text-zinc-800 text-xs shadow-2xs font-semibold">
                  Amazon
                </span>
                <span className="text-zinc-300">•</span>
                <span className="px-2.5 py-1 rounded-md bg-white border border-zinc-200 text-zinc-800 text-xs shadow-2xs font-semibold">
                  Flipkart
                </span>
                <span className="text-zinc-300">•</span>
                <span className="px-2.5 py-1 rounded-md bg-white border border-zinc-200 text-zinc-800 text-xs shadow-2xs font-semibold">
                  Myntra
                </span>
                <span className="text-zinc-300">•</span>
                <span className="px-2.5 py-1 rounded-md bg-white border border-zinc-200 text-zinc-800 text-xs shadow-2xs font-semibold">
                  Meesho
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: 3 Dynamic Floating Cards (Matching Uploaded Design) */}
          <div className="lg:col-span-6 xl:col-span-6 relative flex items-center justify-center pt-6 lg:pt-0">
            
            {/* Ambient Background Container */}
            <div className="relative w-full max-w-[520px] sm:max-w-[560px] h-[480px] sm:h-[540px] md:h-[560px] select-none">
              
              {/* Soft background aura circles for exact screenshot lighting effect */}
              <div className="absolute top-2 right-2 w-72 h-72 bg-amber-200/40 rounded-full blur-2xl pointer-events-none" />
              <div className="absolute bottom-6 left-4 w-72 h-72 bg-purple-200/35 rounded-full blur-2xl pointer-events-none" />

              {/* CARD 1: Wireless Earbuds (Top-Left, tilted counter-clockwise) */}
              <div
                id="hero-card-earbuds"
                onClick={() => onOpenDetails && onOpenDetails(pEarbuds)}
                className="absolute top-0 left-2 sm:left-4 w-[210px] sm:w-[250px] -rotate-6 hover:rotate-0 hover:scale-105 hover:z-30 transition-all duration-300 ease-out cursor-pointer z-10 group"
              >
                <div className="bg-white rounded-[1.8rem] sm:rounded-[2.2rem] p-3.5 sm:p-4 shadow-[0_15px_35px_rgba(0,0,0,0.08)] border border-zinc-150 hover:shadow-2xl transition-shadow">
                  {/* Framed Image Area */}
                  <div className="aspect-[4/3] w-full rounded-2xl overflow-hidden bg-zinc-50 border border-zinc-200/80 relative mb-3 group-hover:border-orange-300 transition-colors">
                    <img
                      src={pEarbuds.image}
                      alt="Wireless Earbuds"
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>

                  {/* Title & Price */}
                  <div className="px-1 pb-1">
                    <h3 className="font-bold text-sm sm:text-base text-zinc-900 tracking-tight truncate">
                      Wireless Earbuds
                    </h3>
                    <div className="flex items-baseline gap-2 mt-1">
                      <span className="text-lg sm:text-xl font-black text-[#F95700]">
                        ₹1,299
                      </span>
                      <span className="text-xs sm:text-sm font-semibold text-zinc-400 line-through">
                        ₹2,499
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* CARD 2: Smart Desk Lamp (Right, tilted clockwise with pink 48% OFF badge) */}
              <div
                id="hero-card-lamp"
                onClick={() => onOpenDetails && onOpenDetails(pLamp)}
                className="absolute top-6 sm:top-10 right-1 sm:right-3 w-[220px] sm:w-[260px] rotate-6 hover:rotate-0 hover:scale-105 hover:z-30 transition-all duration-300 ease-out cursor-pointer z-20 group"
              >
                <div className="relative bg-white rounded-[1.8rem] sm:rounded-[2.2rem] p-3.5 sm:p-4 shadow-[0_15px_35px_rgba(0,0,0,0.08)] border border-zinc-150 hover:shadow-2xl transition-shadow">
                  
                  {/* Top-Right Circular Pink Badge (48% OFF) */}
                  <div className="absolute -top-3.5 -right-3.5 sm:-top-4 sm:-right-4 w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-[#E11D48] text-white flex flex-col items-center justify-center font-black shadow-lg shadow-pink-500/40 z-30 transition-transform group-hover:scale-110">
                    <span className="text-[11px] sm:text-xs leading-none font-black">48%</span>
                    <span className="text-[9px] sm:text-[10px] leading-none font-black mt-0.5 tracking-wider">OFF</span>
                  </div>

                  {/* Framed Image Area */}
                  <div className="aspect-[4/3] w-full rounded-2xl overflow-hidden bg-zinc-50 border border-zinc-200/80 relative mb-3 group-hover:border-orange-300 transition-colors">
                    <img
                      src={pLamp.image}
                      alt="Smart Desk Lamp"
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>

                  {/* Title & Price */}
                  <div className="px-1 pb-1">
                    <h3 className="font-bold text-sm sm:text-base text-zinc-900 tracking-tight truncate">
                      Smart Desk Lamp
                    </h3>
                    <div className="flex items-baseline gap-2 mt-1">
                      <span className="text-lg sm:text-xl font-black text-[#F95700]">
                        ₹799
                      </span>
                      <span className="text-xs sm:text-sm font-semibold text-zinc-400 line-through">
                        ₹1,499
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* CARD 3: Casual Handbag (Bottom-Center, slightly tilted) */}
              <div
                id="hero-card-handbag"
                onClick={() => onOpenDetails && onOpenDetails(pBag)}
                className="absolute bottom-0 sm:bottom-2 left-1/2 -translate-x-1/2 w-[215px] sm:w-[255px] -rotate-2 hover:rotate-0 hover:scale-105 hover:z-30 transition-all duration-300 ease-out cursor-pointer z-20 group"
              >
                <div className="bg-white rounded-[1.8rem] sm:rounded-[2.2rem] p-3.5 sm:p-4 shadow-[0_18px_40px_rgba(0,0,0,0.1)] border border-zinc-150 hover:shadow-2xl transition-shadow">
                  {/* Framed Image Area */}
                  <div className="aspect-[4/3] w-full rounded-2xl overflow-hidden bg-zinc-50 border border-zinc-200/80 relative mb-3 group-hover:border-orange-300 transition-colors">
                    <img
                      src={pBag.image}
                      alt="Casual Handbag"
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>

                  {/* Title & Price */}
                  <div className="px-1 pb-1">
                    <h3 className="font-bold text-sm sm:text-base text-zinc-900 tracking-tight truncate">
                      Casual Handbag
                    </h3>
                    <div className="flex items-baseline gap-2 mt-1">
                      <span className="text-lg sm:text-xl font-black text-[#F95700]">
                        ₹699
                      </span>
                      <span className="text-xs sm:text-sm font-semibold text-zinc-400 line-through">
                        ₹1,499
                      </span>
                    </div>
                  </div>
                </div>
              </div>

            </div>

          </div>

        </div>
      </div>
    </section>
  );
};

