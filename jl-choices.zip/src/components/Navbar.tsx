import React, { useState, useEffect } from 'react';
import { Logo } from './Logo';
import { Search, Flame, Menu, X, Sparkles, ArrowRight, ShieldCheck, Instagram, Youtube, Facebook, Linkedin } from 'lucide-react';
import { CategorySlug } from '../types';
import { BRAND_CONFIG } from '../config/brand';

interface NavbarProps {
  activeRoute: string;
  selectedCategory?: string;
  onNavigate: (route: string, category?: CategorySlug | 'all') => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSearchSubmit?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeRoute,
  selectedCategory,
  onNavigate,
  searchQuery,
  onSearchChange,
  onSearchSubmit
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 15);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks: { label: string; route: string; category?: CategorySlug }[] = [
    { label: 'Home', route: '/' },
    { label: 'Deals', route: '/deals', category: 'deals' },
    { label: 'Trending', route: '/trending', category: 'trending' },
    { label: 'Fashion', route: '/category/fashion', category: 'fashion' },
    { label: 'Gadgets', route: '/category/gadgets', category: 'gadgets' },
    { label: 'Home & Kitchen', route: '/category/home', category: 'home' },
    { label: 'Beauty', route: '/category/beauty', category: 'beauty' },
    { label: 'About', route: '/about' },
  ];

  const isLinkActive = (link: { label: string; route: string; category?: CategorySlug }) => {
    if (link.route === '/' && !link.category) {
      return activeRoute === '/' && (!selectedCategory || selectedCategory === 'all');
    }
    if (link.category) {
      return selectedCategory === link.category;
    }
    return activeRoute === link.route || (link.route !== '/' && activeRoute.startsWith(link.route));
  };

  const handleLinkClick = (route: string, category?: CategorySlug) => {
    setIsMobileMenuOpen(false);
    onNavigate(route, category);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearchSubmit) {
      onSearchSubmit();
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full">
      {/* Top Banner Notice */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 text-zinc-100 text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 text-[11px] sm:text-xs">
            <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-medium text-zinc-200">
              ⚡ Curated daily deals across <span className="text-orange-400 font-semibold">Amazon</span>, <span className="text-blue-400 font-semibold">Flipkart</span>, <span className="text-pink-400 font-semibold">Myntra</span> & <span className="text-purple-400 font-semibold">Meesho</span>
            </span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-[11px] text-zinc-300">
            <button 
              onClick={() => onNavigate('/affiliate-disclosure')}
              className="hover:text-white flex items-center gap-1 transition-colors"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              100% Transparent Affiliate Links
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <nav
        className={`w-full transition-all duration-200 border-b ${
          isScrolled
            ? 'bg-white/95 backdrop-blur-md shadow-sm border-zinc-200/80 py-2.5'
            : 'bg-[#FFFDF9]/95 backdrop-blur-sm border-zinc-200/60 py-3.5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4">
            {/* Left: Logo */}
            <div
              onClick={() => handleLinkClick('/')}
              className="cursor-pointer transition-transform hover:scale-[1.01] active:scale-[0.99] flex-shrink-0 flex items-center"
              id="navbar-logo"
            >
              <Logo />
            </div>

            {/* Middle: Desktop Navigation Links */}
            <div className="hidden lg:flex items-center gap-1 xl:gap-2">
              {navLinks.map((link) => {
                const isActive = isLinkActive(link);
                const buttonId = `nav-item-${link.label.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
                return (
                  <button
                    key={link.route}
                    id={buttonId}
                    onClick={() => handleLinkClick(link.route, link.category)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-all duration-150 whitespace-nowrap cursor-pointer ${
                      isActive
                        ? 'text-pink-600 bg-pink-50 font-bold shadow-2xs'
                        : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100/70'
                    }`}
                  >
                    {link.label}
                  </button>
                );
              })}
            </div>

            {/* Right: Search Box + "Today's Deals" Button */}
            <div className="hidden md:flex items-center gap-3 flex-shrink-0">
              {/* Search Box */}
              <form onSubmit={handleFormSubmit} className="relative">
                <input
                  type="text"
                  placeholder="Search deals, earbuds, lamps..."
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  className="w-48 lg:w-60 pl-9 pr-3 py-1.5 text-xs bg-zinc-100/90 border border-zinc-200 rounded-full focus:bg-white focus:w-64 focus:outline-none focus:ring-2 focus:ring-pink-500/30 focus:border-pink-500 transition-all duration-200"
                />
                <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => onSearchChange('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 text-xs font-bold"
                  >
                    ×
                  </button>
                )}
              </form>

              {/* Today's Deals Button */}
              <button
                id="btn-todays-deals"
                onClick={() => handleLinkClick('/deals', 'deals')}
                className="relative inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold text-white bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 hover:from-orange-600 hover:via-pink-600 hover:to-purple-700 shadow-sm shadow-orange-500/20 active:scale-95 transition-all duration-150"
              >
                <Flame className="w-3.5 h-3.5 text-yellow-300 animate-bounce" />
                <span>Today's Deals</span>
              </button>
            </div>

            {/* Mobile Controls: Search toggle + Hamburger button */}
            <div className="flex items-center gap-2 lg:hidden">
              <button
                onClick={() => setIsSearchExpanded(!isSearchExpanded)}
                className="p-2 rounded-lg text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100"
                aria-label="Search"
              >
                <Search className="w-5 h-5" />
              </button>

              <button
                id="btn-mobile-menu"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 rounded-lg text-zinc-700 hover:text-zinc-900 hover:bg-zinc-100"
                aria-label="Toggle Navigation Menu"
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Expandable Search Row */}
          {isSearchExpanded && (
            <div className="pt-3 pb-2 lg:hidden">
              <form onSubmit={handleFormSubmit} className="relative">
                <input
                  type="text"
                  placeholder="Search products, brands, categories..."
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  autoFocus
                  className="w-full pl-9 pr-8 py-2 text-sm bg-white border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500"
                />
                <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => onSearchChange('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 text-sm font-bold"
                  >
                    ×
                  </button>
                )}
              </form>
            </div>
          )}
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-zinc-200 bg-white px-4 pt-3 pb-6 shadow-xl animate-in slide-in-from-top-2 duration-150">
            <div className="flex flex-col gap-1 mb-4">
              {navLinks.map((link) => {
                const isActive = isLinkActive(link);
                const buttonId = `mobile-nav-item-${link.label.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
                return (
                  <button
                    key={link.route}
                    id={buttonId}
                    onClick={() => handleLinkClick(link.route, link.category)}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-sm font-medium transition-colors cursor-pointer ${
                      isActive
                        ? 'text-pink-600 bg-pink-50 font-bold'
                        : 'text-zinc-700 hover:bg-zinc-50'
                    }`}
                  >
                    <span>{link.label}</span>
                    <ArrowRight className="w-4 h-4 text-zinc-400 opacity-60" />
                  </button>
                );
              })}
            </div>

            {/* Mobile Today's Deals Button */}
            <button
              onClick={() => handleLinkClick('/deals', 'deals')}
              className="w-full py-3 rounded-xl text-center text-sm font-bold text-white bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 shadow-md flex items-center justify-center gap-2"
            >
              <Flame className="w-4 h-4 text-yellow-300" />
              <span>Explore Today's Deals</span>
            </button>

            {/* Mobile Social Links */}
            <div className="mt-4 pt-3 border-t border-zinc-100 flex items-center justify-between">
              <span className="text-xs font-semibold text-zinc-500">Follow Us</span>
              <div className="flex items-center gap-2">
                <a
                  id="mobile-nav-social-instagram"
                  href={BRAND_CONFIG.socials.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Instagram"
                  className="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-600 hover:text-pink-600 hover:bg-pink-50 transition-colors"
                >
                  <Instagram className="w-4 h-4" />
                </a>
                <a
                  id="mobile-nav-social-youtube"
                  href={BRAND_CONFIG.socials.youtube}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="YouTube"
                  className="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-600 hover:text-red-600 hover:bg-red-50 transition-colors"
                >
                  <Youtube className="w-4 h-4" />
                </a>
                <a
                  id="mobile-nav-social-linkedin"
                  href={BRAND_CONFIG.socials.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="LinkedIn"
                  className="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-600 hover:text-sky-600 hover:bg-sky-50 transition-colors"
                >
                  <Linkedin className="w-4 h-4" />
                </a>
                <a
                  id="mobile-nav-social-facebook"
                  href={BRAND_CONFIG.socials.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Facebook"
                  className="w-8 h-8 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-600 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                >
                  <Facebook className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Mobile Footer Meta */}
            <div className="mt-3 pt-3 border-t border-zinc-100 flex items-center justify-between text-xs text-zinc-400">
              <span>Better Finds • Smarter Choices</span>
              <button
                onClick={() => handleLinkClick('/affiliate-disclosure')}
                className="text-pink-600 font-medium"
              >
                Affiliate Disclosure
              </button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};
