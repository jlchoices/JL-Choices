import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  showTagline?: boolean;
  isDark?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  showText = true,
  showTagline = true,
  isDark = false,
}) => {
  // JL sizes (noticeably slightly bigger as requested)
  const jlSizes = {
    sm: 'text-2xl sm:text-[1.75rem]',
    md: 'text-3xl sm:text-[2.5rem] lg:text-[2.85rem]',
    lg: 'text-4xl sm:text-[3.25rem]',
    xl: 'text-5xl sm:text-6xl',
  };

  // Cursive Choices font sizes matching proportionally along baseline
  const choicesSizes = {
    sm: 'text-xl sm:text-2xl',
    md: 'text-2xl sm:text-[2rem] lg:text-[2.25rem]',
    lg: 'text-3xl sm:text-4xl',
    xl: 'text-4xl sm:text-5xl',
  };

  if (!showText) return null;

  return (
    <div className={`inline-flex flex-col justify-center select-none ${className}`}>
      {/* Top row: JL + Choices sitting straight along the baseline */}
      <div className="flex items-baseline leading-none">
        {/* "JL" Monogram: Slightly Bigger with Solid Black 'J' + Orange-to-Pink Gradient 'L' */}
        <div
          className={`inline-flex items-baseline font-black font-['Outfit',sans-serif] tracking-tight ${jlSizes[size]}`}
        >
          <span className={isDark ? 'text-white' : 'text-zinc-950'}>J</span>
          <span className="bg-gradient-to-r from-orange-500 via-pink-500 to-rose-500 bg-clip-text text-transparent">
            L
          </span>
        </div>

        {/* "Choices" Cursive Script Typography snug against JL */}
        <div className="relative inline-flex items-baseline ml-1 sm:ml-1.5">
          <span
            className={`font-logo-script font-['Pacifico',cursive] tracking-normal font-normal ${
              isDark ? 'text-white' : 'text-zinc-950'
            } ${choicesSizes[size]} leading-none`}
          >
            Choices
          </span>
          {/* Smiling curved golden-orange underline stroke */}
          <svg
            className="absolute -bottom-2 sm:-bottom-2.5 left-0 w-full h-1.5 sm:h-2 text-amber-500/90 pointer-events-none"
            viewBox="0 0 100 8"
            fill="none"
            preserveAspectRatio="none"
          >
            <path
              d="M 5,2 Q 50,8 95,2"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
          </svg>
        </div>
      </div>

      {showTagline && (
        <span
          className={`text-[9.5px] sm:text-[11.5px] font-semibold tracking-wide ${
            isDark ? 'text-zinc-400' : 'text-zinc-600'
          } mt-1.5 pl-0.5`}
        >
          Better Finds • Smarter Choices
        </span>
      )}
    </div>
  );
};
