import React from 'react';
import { Product } from '../types';
import { ExternalLink, Star, ArrowUpRight, Flame } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onOpenDetails: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onOpenDetails,
}) => {
  const getMarketplaceBadge = (marketplace: Product['marketplace']) => {
    switch (marketplace) {
      case 'Amazon':
        return {
          bg: 'bg-amber-500/10 text-amber-800 border-amber-300',
          dot: 'bg-amber-500',
          name: 'Amazon',
        };
      case 'Flipkart':
        return {
          bg: 'bg-blue-500/10 text-blue-800 border-blue-300',
          dot: 'bg-blue-500',
          name: 'Flipkart',
        };
      case 'Myntra':
        return {
          bg: 'bg-pink-500/10 text-pink-800 border-pink-300',
          dot: 'bg-pink-500',
          name: 'Myntra',
        };
      case 'Meesho':
        return {
          bg: 'bg-purple-500/10 text-purple-800 border-purple-300',
          dot: 'bg-purple-500',
          name: 'Meesho',
        };
      default:
        return {
          bg: 'bg-zinc-100 text-zinc-800 border-zinc-200',
          dot: 'bg-zinc-400',
          name: marketplace,
        };
    }
  };

  const badgeInfo = getMarketplaceBadge(product.marketplace);

  const handleAffiliateClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.stopPropagation();
  };

  return (
    <div
      id={`product-card-${product.id}`}
      onClick={() => onOpenDetails(product)}
      className="group relative flex flex-col bg-white rounded-2xl border border-zinc-200/80 shadow-xs hover:shadow-xl hover:border-pink-300/80 transition-all duration-300 overflow-hidden cursor-pointer"
    >
      {/* Product Image Area */}
      <div className="relative w-full aspect-4/3 sm:aspect-square bg-zinc-50 overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-500 ease-out"
        />

        {/* Top Badges */}
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between gap-1 pointer-events-none">
          {/* Discount Percentage Badge */}
          <span className="inline-flex items-center px-2 py-1 rounded-lg text-xs font-black bg-gradient-to-r from-orange-500 to-pink-500 text-white shadow-sm">
            {product.discount}% OFF
          </span>

          {/* Optional Special Tag (e.g. Lightning Deal / Best Seller) */}
          {product.badge && (
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-bold bg-zinc-900/85 text-white backdrop-blur-xs shadow-xs">
              <Flame className="w-3 h-3 text-yellow-400" />
              <span className="hidden sm:inline">{product.badge}</span>
            </span>
          )}
        </div>

        {/* Marketplace Pill overlay on bottom-left of image */}
        <div className="absolute bottom-2.5 left-2.5">
          <span
            className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-bold border backdrop-blur-md bg-white/95 ${badgeInfo.bg}`}
          >
            <span className={`w-1.5 h-1.5 rounded-full ${badgeInfo.dot}`} />
            <span>{badgeInfo.name}</span>
          </span>
        </div>
      </div>

      {/* Product Details Body */}
      <div className="flex flex-col flex-1 p-3.5 sm:p-4">
        
        {/* Rating */}
        <div className="flex items-center gap-1.5 mb-1.5">
          <div className="flex items-center text-amber-500">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
          </div>
          <span className="text-xs font-bold text-zinc-900">{product.rating}</span>
          <span className="text-[11px] text-zinc-600">({product.reviewCount.toLocaleString()})</span>
        </div>

        {/* Product Name */}
        <h3 className="font-bold text-sm sm:text-base text-zinc-900 leading-snug line-clamp-2 group-hover:text-pink-600 transition-colors mb-1.5">
          {product.name}
        </h3>

        {/* Short Description */}
        <p className="text-xs text-zinc-600 line-clamp-2 leading-relaxed mb-3">
          {product.shortDescription}
        </p>

        {/* Price Section */}
        <div className="mt-auto pt-2 border-t border-zinc-100 flex items-baseline justify-between gap-2">
          <div className="flex items-baseline gap-1.5">
            <span className="text-lg sm:text-xl font-black text-zinc-900 tracking-tight">
              ₹{product.price.toLocaleString('en-IN')}
            </span>
            {product.originalPrice > product.price && (
              <span className="text-xs text-zinc-600 line-through font-medium">
                ₹{product.originalPrice.toLocaleString('en-IN')}
              </span>
            )}
          </div>
          <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
            Save ₹{(product.originalPrice - product.price).toLocaleString('en-IN')}
          </span>
        </div>

        {/* Actions Row */}
        <div className="mt-3.5 pt-3 border-t border-zinc-100/80 flex items-center gap-2">
          {/* Quick View link */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onOpenDetails(product);
            }}
            className="flex-1 py-2 px-2.5 rounded-xl text-xs font-bold text-zinc-700 bg-zinc-100 hover:bg-zinc-200 transition-colors text-center"
          >
            Details
          </button>

          {/* Primary View Deal CTA (Affiliate link in new tab) */}
          <a
            id={`view-deal-btn-${product.id}`}
            href={product.affiliateUrl}
            target="_blank"
            rel="noopener noreferrer sponsored"
            onClick={handleAffiliateClick}
            className="flex-1 py-2 px-2.5 rounded-xl text-xs font-extrabold text-white bg-gradient-to-r from-orange-500 via-pink-500 to-purple-600 hover:from-orange-600 hover:via-pink-600 hover:to-purple-700 shadow-sm shadow-orange-500/20 active:scale-95 transition-all text-center flex items-center justify-center gap-1"
          >
            <span>View Deal</span>
            <ExternalLink className="w-3 h-3 text-white/90" />
          </a>
        </div>

      </div>
    </div>
  );
};
