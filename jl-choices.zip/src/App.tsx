import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { CategorySection } from './components/CategorySection';
import { ProductGrid } from './components/ProductGrid';
import { TrendingSection } from './components/TrendingSection';
import { DealBanner } from './components/DealBanner';
import { MarketplaceSection } from './components/MarketplaceSection';
import { WhyJLChoices } from './components/WhyJLChoices';
import { Newsletter } from './components/Newsletter';
import { Footer } from './components/Footer';
import { ProductDetailPage } from './components/ProductDetailPage';
import { TrendingPopupModal } from './components/TrendingPopupModal';
import {
  AffiliateDisclosurePage,
  AboutPage,
  ContactPage,
  PrivacyPolicyPage,
  TermsPage
} from './components/StaticPages';
import { PRODUCTS } from './data/products';
import { Product, CategorySlug, MarketplaceType } from './types';

export default function App() {
  const [activeRoute, setActiveRoute] = useState<string>('/');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Initialize route from current window.location.pathname or hash
  useEffect(() => {
    const handleUrlChange = () => {
      const path = window.location.pathname;

      if (path.startsWith('/product/')) {
        const slug = path.replace('/product/', '');
        const found = PRODUCTS.find((p) => p.slug === slug);
        if (found) {
          setSelectedProduct(found);
          setActiveRoute(path);
          return;
        }
      }

      if (path.startsWith('/category/')) {
        const cat = path.replace('/category/', '') as CategorySlug;
        setSelectedCategory(cat);
        setSelectedProduct(null);
        setActiveRoute(path);
        scrollToTarget('products-section');
        return;
      }

      if (path === '/deals') {
        setSelectedCategory('deals');
        setSelectedProduct(null);
        setActiveRoute('/deals');
        scrollToTarget('products-section');
        return;
      }

      if (path === '/trending') {
        setSelectedCategory('trending');
        setSelectedProduct(null);
        setActiveRoute('/trending');
        scrollToTarget('trending-section');
        return;
      }

      if (['/about', '/contact', '/privacy-policy', '/terms', '/affiliate-disclosure'].includes(path)) {
        setSelectedProduct(null);
        setActiveRoute(path);
        return;
      }

      // Default home
      setActiveRoute('/');
      setSelectedProduct(null);
    };

    handleUrlChange();
    window.addEventListener('popstate', handleUrlChange);
    return () => window.removeEventListener('popstate', handleUrlChange);
  }, []);

  // Helper to scroll smoothly to a page section with sticky navbar offset
  const scrollToTarget = (elementId: string) => {
    const tryScroll = (attemptsLeft: number) => {
      const el = document.getElementById(elementId);
      if (el) {
        const yOffset = -75;
        const y = el.getBoundingClientRect().top + window.pageYOffset + yOffset;
        window.scrollTo({ top: Math.max(0, y), behavior: 'smooth' });
      } else if (attemptsLeft > 0) {
        setTimeout(() => tryScroll(attemptsLeft - 1), 80);
      }
    };
    setTimeout(() => tryScroll(3), 50);
  };

  // Safe navigation function updating window history and state
  const navigateTo = (route: string, category?: CategorySlug | 'all') => {
    if (route === '/') {
      setSelectedProduct(null);
      if (category && category !== 'all') {
        setSelectedCategory(category);
        setActiveRoute('/');
        window.history.pushState({}, '', '/');
        scrollToTarget('products-section');
      } else {
        setSelectedCategory('all');
        setActiveRoute('/');
        window.history.pushState({}, '', '/');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
      return;
    }

    if (route === '/deals') {
      setSelectedProduct(null);
      setSelectedCategory('deals');
      setActiveRoute('/deals');
      window.history.pushState({}, '', '/deals');
      scrollToTarget('products-section');
      return;
    }

    if (route === '/trending') {
      setSelectedProduct(null);
      setSelectedCategory('trending');
      setActiveRoute('/trending');
      window.history.pushState({}, '', '/trending');
      scrollToTarget('trending-section');
      return;
    }

    if (route.startsWith('/category/')) {
      setSelectedProduct(null);
      const cat = category || (route.replace('/category/', '') as CategorySlug);
      setSelectedCategory(cat);
      setActiveRoute(route);
      window.history.pushState({}, '', route);
      scrollToTarget('products-section');
      return;
    }

    // Static pages (/about, /contact, /privacy-policy, /terms, /affiliate-disclosure)
    setSelectedProduct(null);
    setActiveRoute(route);
    window.history.pushState({}, '', route);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Open product detail page
  const handleOpenProductDetails = (product: Product) => {
    setSelectedProduct(product);
    const newRoute = `/product/${product.slug}`;
    setActiveRoute(newRoute);
    window.history.pushState({}, '', newRoute);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Scroll to products / deals section
  const handleScrollToProducts = (categorySlug?: CategorySlug) => {
    if (categorySlug) {
      setSelectedCategory(categorySlug);
    }
    if (selectedProduct || activeRoute !== '/') {
      navigateTo('/');
      setTimeout(() => {
        const el = document.getElementById('products-section');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    } else {
      const el = document.getElementById('products-section');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Scroll to trending section
  const handleExploreAllTrending = () => {
    if (selectedProduct || activeRoute !== '/') {
      navigateTo('/');
      setTimeout(() => {
        const el = document.getElementById('trending-section');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    } else {
      const el = document.getElementById('trending-section');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Filter by marketplace from marketplace section
  const handleSelectMarketplace = (marketplace: MarketplaceType) => {
    if (selectedProduct || activeRoute !== '/') {
      navigateTo('/');
    }
    setSearchQuery(marketplace);
    setTimeout(() => {
      const el = document.getElementById('products-section');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 50);
  };

  // Category select from category cards or pills
  const handleSelectCategory = (categorySlug: CategorySlug | 'all') => {
    if (selectedProduct || activeRoute !== '/') {
      setSelectedProduct(null);
      setActiveRoute(categorySlug === 'all' ? '/' : `/category/${categorySlug}`);
      window.history.pushState({}, '', categorySlug === 'all' ? '/' : `/category/${categorySlug}`);
    }
    setSelectedCategory(categorySlug);
    const el = document.getElementById('products-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FFFDF9] text-zinc-900 selection:bg-pink-500 selection:text-white">
      {/* Sticky Header */}
      <Navbar
        activeRoute={activeRoute}
        selectedCategory={selectedCategory}
        onNavigate={navigateTo}
        searchQuery={searchQuery}
        onSearchChange={(q) => {
          setSearchQuery(q);
          if (q.trim() && (selectedProduct || activeRoute !== '/')) {
            navigateTo('/');
          }
        }}
        onSearchSubmit={() => handleScrollToProducts()}
      />

      {/* Main Page Routing Switcher */}
      <main className="flex-1">
        {/* 1. Product Detail Page */}
        {selectedProduct ? (
          <ProductDetailPage
            product={selectedProduct}
            allProducts={PRODUCTS}
            onBack={() => navigateTo('/')}
            onOpenDetails={handleOpenProductDetails}
            onNavigateCategory={(cat) => navigateTo(`/category/${cat}`, cat)}
          />
        ) : activeRoute === '/affiliate-disclosure' ? (
          /* 2. Affiliate Disclosure Page */
          <AffiliateDisclosurePage onBack={() => navigateTo('/')} />
        ) : activeRoute === '/about' ? (
          /* 3. About Page */
          <AboutPage onBack={() => navigateTo('/')} />
        ) : activeRoute === '/contact' ? (
          /* 4. Contact Page */
          <ContactPage onBack={() => navigateTo('/')} />
        ) : activeRoute === '/privacy-policy' ? (
          /* 5. Privacy Policy Page */
          <PrivacyPolicyPage onBack={() => navigateTo('/')} />
        ) : activeRoute === '/terms' ? (
          /* 6. Terms & Conditions Page */
          <TermsPage onBack={() => navigateTo('/')} />
        ) : (
          /* 7. Primary Home / Category Discovery Experience */
          <>
            {/* Hero Section */}
            <Hero
              onExploreDeals={() => handleScrollToProducts('deals')}
              onExploreTrending={() => {
                const el = document.getElementById('trending-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              onOpenDetails={handleOpenProductDetails}
            />

            {/* Category Section */}
            <CategorySection
              selectedCategory={selectedCategory}
              onSelectCategory={handleSelectCategory}
            />

            {/* Trending Horizontal Section */}
            <TrendingSection
              products={PRODUCTS}
              onOpenDetails={handleOpenProductDetails}
            />

            {/* Deals You Don't Want To Miss Banners */}
            <DealBanner
              onExploreCategory={(cat) => handleScrollToProducts(cat)}
            />

            {/* Product Section: Today's Top Picks with Search, Category Filter, and Sorting */}
            <ProductGrid
              products={PRODUCTS}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              onOpenDetails={handleOpenProductDetails}
            />

            {/* Marketplace Section */}
            <MarketplaceSection
              onSelectMarketplace={handleSelectMarketplace}
            />

            {/* Why JL Choices */}
            <WhyJLChoices />

            {/* Newsletter Subscription */}
            <Newsletter />
          </>
        )}
      </main>

      {/* Footer */}
      <Footer onNavigate={navigateTo} />

      {/* Auto Trending Products Welcome Pop-up */}
      <TrendingPopupModal
        products={PRODUCTS}
        onOpenDetails={handleOpenProductDetails}
        onExploreAllTrending={handleExploreAllTrending}
      />
    </div>
  );
}
