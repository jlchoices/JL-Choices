import { Product, CategoryInfo, MarketplaceInfo } from '../types';

/**
 * =========================================================================
 * JL CHOICES - PRODUCT CATALOG & AFFILIATE DATA
 * =========================================================================
 * 
 * TO ADD A NEW PRODUCT:
 * Simply copy one of the objects below and add it to the `PRODUCTS` array.
 * 
 * TO UPDATE AN AFFILIATE LINK:
 * Change the `affiliateUrl` field with your actual affiliate tracking link
 * from Amazon Associates, Flipkart Affiliate, EarnKaro, Myntra, or Meesho.
 * 
 * TO UPDATE AN IMAGE:
 * Replace the `image` field with any image URL or local path in `/public`.
 */

export const PRODUCTS: Product[] = [
  // 1. User's Example Product 1 - Amazon Earbuds
  {
    id: 1,
    slug: 'wireless-bluetooth-earbuds',
    name: 'Wireless Bluetooth Earbuds with ANC & 40H Playtime',
    shortDescription: 'Active Noise Cancellation, deep bass audio, dual-mic ENC for clear calls, IPX5 water resistance.',
    description: 'Experience immersive studio-grade sound with ultra-low latency and 40 hours of combined playtime. Features intuitive touch controls, fast Type-C charging (10 mins charge = 2 hours playtime), and ergonomic feather-light in-ear fit designed for workouts and daily commutes.',
    features: [
      'Active Noise Cancellation (up to 30dB reduction)',
      '40 Hours total backup with compact pocket charging case',
      'Quad mic setup with AI environmental noise cancellation',
      'Instant wake & pair Bluetooth v5.3 connectivity',
      'IPX5 sweat and splash resistance'
    ],
    image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&auto=format&fit=crop&q=80',
    additionalImages: [
      'https://images.unsplash.com/photo-1572536147248-ac59a8abfa4b?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=800&auto=format&fit=crop&q=80'
    ],
    price: 1299,
    originalPrice: 2499,
    discount: 48,
    rating: 4.5,
    reviewCount: 3840,
    marketplace: 'Amazon',
    category: 'gadgets',
    affiliateUrl: 'https://www.amazon.in/dp/B09XYZ1234?tag=jlchoices-21',
    isTrending: true,
    isTopPick: true,
    isDeal: true,
    badge: 'Lightning Deal'
  },

  // 2. User's Example Product 2 - Flipkart Desk Lamp
  {
    id: 2,
    slug: 'smart-led-desk-lamp',
    name: 'Smart LED Desk Lamp with Eye-Care & Wireless Charging',
    shortDescription: 'Adjustable color temperatures, smooth touch dimming, and built-in smartphone charging pad.',
    description: 'Upgrade your study and work desk with flicker-free, non-glare illumination. Offers 5 brightness levels and 3 distinct color temperatures (Warm, Natural, Cool White) to prevent eye strain during late-night reading or laptop work.',
    features: [
      '10W Qi fast wireless phone charging base built-in',
      'Flicker-free eye protection CRI > 90 optical lens',
      'Touch control panel with 45-minute auto-off sleep timer',
      'Flexible foldable multi-angle gooseneck arm'
    ],
    image: 'https://images.unsplash.com/photo-1534073828943-f801091bb18c?w=800&auto=format&fit=crop&q=80',
    additionalImages: [
      'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800&auto=format&fit=crop&q=80'
    ],
    price: 799,
    originalPrice: 1499,
    discount: 47,
    rating: 4.4,
    reviewCount: 1920,
    marketplace: 'Flipkart',
    category: 'gadgets',
    affiliateUrl: 'https://www.flipkart.com/smart-led-desk-lamp/p/itm12345?affid=jlchoices',
    isTrending: true,
    isTopPick: true,
    isDeal: true,
    badge: 'Top Rated'
  },

  // 3. User's Example Product 3 - Myntra Handbag
  {
    id: 3,
    slug: 'womens-casual-tote-handbag',
    name: "Women's Casual Vegan Leather Shoulder Tote Handbag",
    shortDescription: 'Spacious multi-compartment design, premium textured finish, and water-resistant lining.',
    description: 'A stylish and practical everyday shoulder bag tailored for college, office, and casual weekend outings. Built with durable, scratch-resistant vegan PU leather, robust gold-tone zippers, and ample space for a 13-inch laptop, water bottle, and daily makeup essentials.',
    features: [
      'Premium textured vegan PU leather outer body',
      '3 zippered main compartments + 2 inner organizer slip pockets',
      'Reinforced comfort shoulder straps for all-day carry',
      'Detachable adjustable crossbody strap included'
    ],
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop&q=80',
    additionalImages: [
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&auto=format&fit=crop&q=80'
    ],
    price: 699,
    originalPrice: 1499,
    discount: 53,
    rating: 4.6,
    reviewCount: 2410,
    marketplace: 'Myntra',
    category: 'fashion',
    affiliateUrl: 'https://www.myntra.com/handbags/jlchoices/12345',
    isTrending: true,
    isTopPick: true,
    isDeal: true,
    badge: 'Trending Fashion'
  },

  // 4. User's Example Product 4 - Meesho Kitchen Organizer
  {
    id: 4,
    slug: 'kitchen-storage-organizer-rack',
    name: 'Multi-Tier Kitchen Storage Organizer & Spice Rack',
    shortDescription: 'Space-saving rust-free carbon steel rack for pantry, countertops, and spices.',
    description: 'Transform cluttered kitchen countertops into an orderly culinary workspace. This heavy-duty 2-tier rack holds up to 20kg of spice jars, condiment bottles, canisters, and oil cruets. Features anti-skid rubber feet that protect surfaces from scratches.',
    features: [
      'Heavy-gauge carbon steel with anti-rust matte coating',
      'Non-slip rubber base feet prevent slipping and scratches',
      'Tool-free fast assembly in under 3 minutes',
      'Elevated guard rails keep jars from falling off'
    ],
    image: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?w=800&auto=format&fit=crop&q=80',
    price: 399,
    originalPrice: 799,
    discount: 50,
    rating: 4.3,
    reviewCount: 1540,
    marketplace: 'Meesho',
    category: 'home',
    affiliateUrl: 'https://www.meesho.com/kitchen-organizer-tier-rack/p/67890?src=jlchoices',
    isTrending: false,
    isTopPick: true,
    isDeal: true,
    badge: 'Budget Hero'
  },

  // 5. Fast Charging 20000mAh Power Bank (Amazon)
  {
    id: 5,
    slug: '20000mah-fast-charging-power-bank',
    name: '20000mAh 22.5W Fast Charging Power Bank with Digital Display',
    shortDescription: 'Triple output ports (Type-C PD + 2 USB-A), flight-approved battery, and LED percentage screen.',
    description: 'Never run out of phone battery on long travel days. Charges modern smartphones up to 50% in just 30 minutes with Power Delivery 3.0 and Quick Charge 3.0 support. Includes 12 layers of circuit chip protection.',
    features: [
      'Real-time numerical LED battery percentage indicator',
      '22.5W two-way fast charge Type-C input/output',
      'Simultaneously charges 3 devices safely',
      'Bureau of Indian Standards (BIS) certified safety chips'
    ],
    image: 'https://images.unsplash.com/photo-1609592426867-0c62c2fca94c?w=800&auto=format&fit=crop&q=80',
    price: 1499,
    originalPrice: 2999,
    discount: 50,
    rating: 4.7,
    reviewCount: 5120,
    marketplace: 'Amazon',
    category: 'gadgets',
    affiliateUrl: 'https://www.amazon.in/dp/B08POWERBK?tag=jlchoices-21',
    isTrending: true,
    isTopPick: true,
    isDeal: true,
    badge: 'Amazon Choice'
  },

  // 6. Premium Oversized Graphic Cotton T-Shirt (Myntra)
  {
    id: 6,
    slug: 'oversized-heavyweight-cotton-tshirt',
    name: 'Pure Heavyweight Cotton Oversized Streetwear Graphic T-Shirt',
    shortDescription: '240 GSM pre-shrunk combed cotton, drop-shoulder relaxed cut, high-density screen print.',
    description: 'Effortless street style tailored for everyday Indian weather. Made with 100% super-combed bio-washed cotton that stays soft and retains vibrant color through dozens of washes without pilling or shrinkage.',
    features: [
      '240 GSM heavyweight premium cotton breathable weave',
      'Drop shoulder contemporary boxy streetwear silhouette',
      'Ribbed lycra collar that prevents sagging over time',
      'Eco-friendly crack-resistant chest artwork print'
    ],
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&auto=format&fit=crop&q=80',
    price: 499,
    originalPrice: 1299,
    discount: 61,
    rating: 4.5,
    reviewCount: 3100,
    marketplace: 'Myntra',
    category: 'fashion',
    affiliateUrl: 'https://www.myntra.com/tshirts/jlchoices/oversized-tee',
    isTrending: true,
    isTopPick: false,
    isDeal: true,
    badge: '61% OFF'
  },

  // 7. Vitamin C Brightening Face Serum (Flipkart)
  {
    id: 7,
    slug: 'vitamin-c-glow-face-serum',
    name: '10% Vitamin C Radiance & Dark Spot Correction Serum (30ml)',
    shortDescription: 'Enriched with pure Ethyl Ascorbic Acid, Hyaluronic Acid, and Ferulic Acid for radiant glow.',
    description: 'A dermatologically tested lightweight facial serum that penetrates deep into skin pores to fade dark spots, even out skin tone, and restore healthy natural luminescence without any greasy residue.',
    features: [
      'Potent stable 10% Vitamin C + 0.5% Ferulic Acid formula',
      'Hyaluronic acid hydrates skin barrier and plumps fine lines',
      'Paraben-free, sulfate-free, and fragrance-free formulation',
      'Fast absorbing water-light texture suitable for all skin types'
    ],
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=800&auto=format&fit=crop&q=80',
    price: 349,
    originalPrice: 699,
    discount: 50,
    rating: 4.6,
    reviewCount: 4200,
    marketplace: 'Flipkart',
    category: 'beauty',
    affiliateUrl: 'https://www.flipkart.com/beauty-serum/p/itm54321?affid=jlchoices',
    isTrending: true,
    isTopPick: true,
    isDeal: true,
    badge: 'Best Seller'
  },

  // 8. Minimalist Ceramic Donut Flower Vase (Meesho)
  {
    id: 8,
    slug: 'minimalist-ceramic-donut-flower-vase',
    name: 'Nordic Ceramic Donut Vase for Pampas Grass & Living Room Decor',
    shortDescription: 'Modern hollow round aesthetic vase with textured matte terracotta beige glaze.',
    description: 'Elevate your living room coffee table, TV console, or bedroom nightstand with this viral Scandinavian donut ceramic vase. Handcrafted with premium ceramic clay and finished with an elegant unglazed sand texture.',
    features: [
      'Artistic hollow circle donut silhouette',
      'Durable fired ceramic with waterproof interior finish',
      'Stands stable with non-scratch padded bottom base',
      'Perfect for dry flowers, pampas grass, or solo botanical stems'
    ],
    image: 'https://images.unsplash.com/photo-1581783342308-f792dbdd27c5?w=800&auto=format&fit=crop&q=80',
    price: 299,
    originalPrice: 799,
    discount: 62,
    rating: 4.4,
    reviewCount: 980,
    marketplace: 'Meesho',
    category: 'home',
    affiliateUrl: 'https://www.meesho.com/donut-vase/p/89123?src=jlchoices',
    isTrending: false,
    isTopPick: false,
    isDeal: true,
    badge: 'Under ₹300'
  },

  // 9. Ergonomic Rechargeable Silent Wireless Mouse (Amazon)
  {
    id: 9,
    slug: 'ergonomic-silent-wireless-mouse',
    name: 'Ergonomic Dual-Mode Wireless Mouse with Silent Click & 2400 DPI',
    shortDescription: 'Bluetooth 5.2 + 2.4GHz USB nano receiver, whisper-quiet clicks, and 60-day battery life.',
    description: 'Say goodbye to click noise during work meetings and study sessions. Ergonomically contoured thumb rest prevents wrist fatigue, while multi-level adjustable DPI switches seamlessly across office tasks and creative photo editing.',
    features: [
      'Dual connection mode: connect up to 2 computers effortlessly',
      '90% sound reduction silent micro-switches',
      'Built-in 500mAh lithium rechargeable battery via Type-C',
      '3-level adjustable optical sensor (800 / 1600 / 2400 DPI)'
    ],
    image: 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=800&auto=format&fit=crop&q=80',
    price: 599,
    originalPrice: 1299,
    discount: 54,
    rating: 4.5,
    reviewCount: 2890,
    marketplace: 'Amazon',
    category: 'accessories',
    affiliateUrl: 'https://www.amazon.in/dp/B08MOUSE01?tag=jlchoices-21',
    isTrending: true,
    isTopPick: true,
    isDeal: true,
    badge: 'Work From Home'
  },

  // 10. Stainless Steel Double-Wall Vacuum Insulated Water Bottle (Flipkart)
  {
    id: 10,
    slug: 'insulated-stainless-steel-water-bottle',
    name: '1000ml Thermal Stainless Steel Insulated Flask with Sipper Lid',
    shortDescription: 'Keeps drinks ice-cold for 24 hours or piping hot for 12 hours. 100% leakproof BPA-free.',
    description: 'Crafted with food-grade 304 18/8 stainless steel that never transfers metallic taste or sweats on the exterior. Comes with an ergonomic carry handle and a one-click pop-up straw spout for easy hydration at the gym, office, or hiking trails.',
    features: [
      'Double-wall vacuum insulation with copper lining',
      'Powder-coated matte exterior gives slip-resistant grip',
      '100% leakproof silicone seal with safety locking latch',
      'BPA-free, phthalate-free, non-toxic eco-friendly materials'
    ],
    image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800&auto=format&fit=crop&q=80',
    price: 499,
    originalPrice: 999,
    discount: 50,
    rating: 4.7,
    reviewCount: 3670,
    marketplace: 'Flipkart',
    category: 'accessories',
    affiliateUrl: 'https://www.flipkart.com/thermal-bottle/p/itm67890?affid=jlchoices',
    isTrending: false,
    isTopPick: true,
    isDeal: true,
    badge: 'Hot Value'
  },

  // 11. Men's Minimalist Sneaker Shoes (Myntra)
  {
    id: 11,
    slug: 'mens-minimalist-white-sneakers',
    name: "Men's Clean Casual Low-Top Vegan Leather Sneakers",
    shortDescription: 'Cushioned memory foam insole, breathable perforated vamp, and non-slip rubber cupsole.',
    description: 'The quintessential white sneaker that effortlessly pairs with denim jeans, chinos, or relaxed shorts. Engineered with lightweight shock-absorbing EVA midsole and soft padded collar for all-day comfort without foot blisters.',
    features: [
      'Water-repellent wipe-clean synthetic leather upper',
      'High-resilience ortholite memory foam footbed',
      'Vulcanized anti-skid rubber sole with grip traction',
      'Minimalist monochrome aesthetic without loud branding'
    ],
    image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800&auto=format&fit=crop&q=80',
    price: 899,
    originalPrice: 2199,
    discount: 59,
    rating: 4.5,
    reviewCount: 1840,
    marketplace: 'Myntra',
    category: 'fashion',
    affiliateUrl: 'https://www.myntra.com/shoes/jlchoices/white-sneakers',
    isTrending: true,
    isTopPick: false,
    isDeal: true,
    badge: '59% OFF'
  },

  // 12. Waterproof Matte Liquid Lipstick Set of 4 (Amazon)
  {
    id: 12,
    slug: 'matte-liquid-lipstick-set',
    name: '12-Hour Non-Transfer Matte Liquid Lipstick Nude Shades Kit (Set of 4)',
    shortDescription: 'Transfer-proof velvet matte finish infused with Vitamin E and Jojoba oil for hydrated lips.',
    description: 'Four everyday flattering nude and rose shades designed specially for Indian skin tones. Glides on smooth like butter, sets into an ultra-comfortable lightweight matte coat that withstands meals and coffee without smudging.',
    features: [
      'Transfer-proof & smudge-proof lasting up to 12 hours',
      'Infused with Vitamin E, Shea Butter, and Sweet Almond Oil',
      'Highly pigmented single-stroke color payoff',
      '100% cruelty-free, vegan certified, and lead-free'
    ],
    image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=800&auto=format&fit=crop&q=80',
    price: 449,
    originalPrice: 999,
    discount: 55,
    rating: 4.4,
    reviewCount: 2210,
    marketplace: 'Amazon',
    category: 'beauty',
    affiliateUrl: 'https://www.amazon.in/dp/B08LIPSTICK?tag=jlchoices-21',
    isTrending: false,
    isTopPick: false,
    isDeal: true,
    badge: 'Festive Pick'
  }
];

export const CATEGORIES: CategoryInfo[] = [
  {
    id: 'trending',
    name: 'Trending',
    icon: '🔥',
    count: 8,
    description: 'Hot products taking Indian social media and markets by storm.',
    color: 'from-orange-500 to-pink-500'
  },
  {
    id: 'deals',
    name: 'Best Deals',
    icon: '💰',
    count: 12,
    description: 'Heavily discounted products verified with high savings.',
    color: 'from-pink-500 to-purple-600'
  },
  {
    id: 'gadgets',
    name: 'Gadgets',
    icon: '📱',
    count: 3,
    description: 'Smart electronics, audio gear, lamps, and daily productivity tech.',
    color: 'from-blue-500 to-indigo-600'
  },
  {
    id: 'fashion',
    name: 'Fashion',
    icon: '👕',
    count: 3,
    description: 'Trendy clothing, bags, footwear, and stylish casuals.',
    color: 'from-amber-500 to-orange-600'
  },
  {
    id: 'home',
    name: 'Home & Kitchen',
    icon: '🏠',
    count: 2,
    description: 'Kitchen organizers, aesthetic decor, and home essentials.',
    color: 'from-emerald-500 to-teal-600'
  },
  {
    id: 'beauty',
    name: 'Beauty',
    icon: '💄',
    count: 2,
    description: 'Derm-tested serums, makeup kits, and personal care finds.',
    color: 'from-rose-500 to-pink-600'
  },
  {
    id: 'accessories',
    name: 'Accessories',
    icon: '🎧',
    count: 2,
    description: 'Flasks, ergonomic gear, daily organizers, and tech add-ons.',
    color: 'from-purple-500 to-violet-600'
  },
  {
    id: 'top-picks',
    name: 'Top Picks',
    icon: '⭐',
    count: 6,
    description: 'Handpicked products that provide maximum value per rupee.',
    color: 'from-yellow-500 to-amber-600'
  }
];

export const MARKETPLACES: MarketplaceInfo[] = [
  {
    id: 'Amazon',
    name: 'Amazon India',
    tagline: 'Electronics, Tech & Everyday Essentials',
    description: 'Vast selection, fast Prime delivery, and verified customer reviews on gadgets and lifestyle goods.',
    accentColor: '#FF9900',
    badgeBg: 'bg-amber-100 text-amber-900 border-amber-300',
    badgeText: 'Amazon',
    logo: 'https://images.unsplash.com/photo-1523474255658-4af61b168344?w=100&auto=format&fit=crop&q=80',
    website: 'https://www.amazon.in'
  },
  {
    id: 'Flipkart',
    name: 'Flipkart',
    tagline: 'Smart Devices, Appliances & Fashion',
    description: "India's beloved homegrown shopping hub with massive SuperCoin deals and Big Billion Day offers.",
    accentColor: '#2874F0',
    badgeBg: 'bg-blue-100 text-blue-900 border-blue-300',
    badgeText: 'Flipkart',
    logo: 'https://images.unsplash.com/photo-1557821552-17105176677c?w=100&auto=format&fit=crop&q=80',
    website: 'https://www.flipkart.com'
  },
  {
    id: 'Myntra',
    name: 'Myntra',
    tagline: 'Curated Trends, Footwear & Beauty',
    description: 'The fashion authority for modern Indian youth, featuring top domestic and international apparel brands.',
    accentColor: '#FF3F6C',
    badgeBg: 'bg-pink-100 text-pink-900 border-pink-300',
    badgeText: 'Myntra',
    logo: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=100&auto=format&fit=crop&q=80',
    website: 'https://www.myntra.com'
  },
  {
    id: 'Meesho',
    name: 'Meesho',
    tagline: 'Budget Value, Kitchen & Home Finds',
    description: 'Direct-from-manufacturer pricing delivering incredible budget finds and functional home organizers.',
    accentColor: '#800080',
    badgeBg: 'bg-purple-100 text-purple-900 border-purple-300',
    badgeText: 'Meesho',
    logo: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=100&auto=format&fit=crop&q=80',
    website: 'https://www.meesho.com'
  }
];
