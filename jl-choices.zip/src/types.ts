export type MarketplaceType = 'Amazon' | 'Flipkart' | 'Myntra' | 'Meesho';

export type CategorySlug =
  | 'trending'
  | 'deals'
  | 'gadgets'
  | 'fashion'
  | 'home'
  | 'beauty'
  | 'accessories'
  | 'top-picks';

export interface Product {
  id: number;
  slug: string;
  name: string;
  shortDescription: string;
  description: string;
  features: string[];
  image: string;
  additionalImages?: string[];
  price: number;
  originalPrice: number;
  discount: number; // percentage e.g. 48 for 48%
  rating: number; // e.g. 4.5
  reviewCount: number;
  marketplace: MarketplaceType;
  category: CategorySlug;
  affiliateUrl: string;
  isTrending?: boolean;
  isTopPick?: boolean;
  isDeal?: boolean;
  badge?: string; // e.g. "Lightning Deal", "Best Seller", "Editor's Choice"
  updatedAt?: string;
}

export interface CategoryInfo {
  id: CategorySlug;
  name: string;
  icon: string;
  count: number;
  description: string;
  color: string;
}

export interface MarketplaceInfo {
  id: MarketplaceType;
  name: string;
  tagline: string;
  description: string;
  accentColor: string;
  badgeBg: string;
  badgeText: string;
  logo: string;
  website: string;
}
