/**
 * JL CHOICES BRAND CONFIGURATION
 * 
 * Edit this file to easily customize your website's:
 * - Brand name & Taglines
 * - Affiliate tracking IDs & Default link templates
 * - Social media links
 * - Contact information
 * - Disclaimers
 */

export const BRAND_CONFIG = {
  name: 'JL Choices',
  tagline: 'Better Finds • Smarter Choices',
  subTagline: 'Deals • Trending Products • Budget Finds',
  description: 'Discover trending products, amazing deals and budget-friendly finds from Amazon, Flipkart, Myntra, and Meesho.',
  supportEmail: 'contact@jlchoices.com',
  location: 'India',
  
  // Brand color palette references
  colors: {
    orange: '#F97316',
    pink: '#EC4899',
    yellow: '#EAB308',
    purple: '#8B5CF6',
    dark: '#18181B',
  },

  // Social Media Links
  socials: {
    instagram: 'https://www.instagram.com/jlchoices/',
    youtube: 'https://www.youtube.com/@JLChoices',
    linkedin: 'https://www.linkedin.com/company/jlchoices/',
    facebook: 'https://www.facebook.com/profile.php',
    telegram: 'https://t.me/jlchoicesdeals',
  },

  // Affiliate disclosure statement (complying with FTC and ASCI guidelines)
  affiliateDisclosureText: 'Some links on JL Choices may be affiliate links. If you purchase through qualifying links, we may earn a commission at no additional cost to you.',
  
  // Default fallback affiliate URLs or affiliate tags
  affiliateDefaults: {
    amazonTag: 'jlchoices-21',
    flipkartTag: 'jlchoices',
    myntraTag: 'jlchoices',
    meeshoTag: 'jlchoices',
  }
};
